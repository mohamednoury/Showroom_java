module gestioncar {
	requires javafx.controls;
	requires java.desktop;
	requires javafx.fxml;
	requires javafx.graphics;
	requires java.rmi;
	requires java.sql;
	requires javafx.base;
	
	
	opens application to javafx.graphics, javafx.fxml;
}
