package application;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;



public class addNewClientController {

    @FXML
    private TextField clientLastName;

    @FXML
    private TextField clientFirstName;

    @FXML
    private TextField clientCIN;

    @FXML
    private TextField clientAddress;

    @FXML
    private TextField clientPhone;

    @FXML
    private Button addClient;
    
    @FXML
    private Button cancelInformation; 

    @FXML
    void ajouter(ActionEvent event) {
        String lastName = clientLastName.getText();
        String firstName = clientFirstName.getText();
        String cin = clientCIN.getText();
        String address = clientAddress.getText();
        String phone = clientPhone.getText();

        clients client = new clients(lastName, firstName, cin, address, phone);
        insertClient(client);

        // Clear input fields
        clientLastName.setText("");
        clientFirstName.setText("");
        clientCIN.setText("");
        clientAddress.setText("");
        clientPhone.setText("");
    }

    private void insertClient(clients client) {
        try {
            // Assuming you have a method to get the database connection
            Connection connection = MysqlConnection.getDBConnection();

            // SQL query to insert a new client into the database
            String sql = "INSERT INTO `clients` (`nom`, `prenom`, `cin`, `adresse`, `numero_telephone`) VALUES (?, ?, ?, ?, ?);";

            PreparedStatement statement = connection.prepareStatement(sql);
        	statement.setString(1, client.getLastName());
            statement.setString(2, client.getFirstName());
            statement.setString(3, client.getCIN());
            statement.setString(4, client.getAddress());
            statement.setString(5, client.getPhone());

            statement.executeUpdate();
            
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    @FXML
    void cancelInformation(ActionEvent event) {
        // Clear input fields when the cancel button is clicked
        clientLastName.setText("");
        clientFirstName.setText("");
        clientCIN.setText("");
        clientAddress.setText("");
        clientPhone.setText("");
    }
	 private Stage stage;
	 private Scene scene;
	 private Parent root;
  
	  @FXML
	  void SwitchToAddClient(ActionEvent event) throws IOException {
		  root = FXMLLoader.load(getClass().getResource("addClient.fxml"));
		  stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		  scene = new Scene(root);
		  stage.setScene(scene);
		  stage.show();
	  }
	 
  @FXML
  void SwitchToAddProduit(ActionEvent event) throws IOException {
	  root = FXMLLoader.load(getClass().getResource("nouv_vehicule.fxml"));
	  stage = (Stage)((Node)event.getSource()).getScene().getWindow();
	  scene = new Scene(root);
	  stage.setScene(scene);
	  stage.show();
  }

  @FXML
  void SwitchToAddVehicule(ActionEvent event) throws IOException {
  	  root = FXMLLoader.load(getClass().getResource("nouv_vehicule.fxml"));
    	  stage = (Stage)((Node)event.getSource()).getScene().getWindow();
    	  scene = new Scene(root);
    	  stage.setScene(scene);
    	  stage.show();
  }

  @FXML
  void SwitchToClients(ActionEvent event) throws IOException {
  	  root = FXMLLoader.load(getClass().getResource("liste_des_clients.fxml"));
    	  stage = (Stage)((Node)event.getSource()).getScene().getWindow();
    	  scene = new Scene(root);
    	  stage.setScene(scene);
    	  stage.show();
  }

  @FXML
  void SwitchToDashboard(ActionEvent event) throws IOException {
  	  root = FXMLLoader.load(getClass().getResource("dashboardVoiture.fxml"));
    	  stage = (Stage)((Node)event.getSource()).getScene().getWindow();
    	  scene = new Scene(root);
    	  stage.setScene(scene);
    	  stage.show();
  }

  @FXML
  void SwitchToEmploye(ActionEvent event) throws IOException {
  	  root = FXMLLoader.load(getClass().getResource("liste_des_employes.fxml"));
    	  stage = (Stage)((Node)event.getSource()).getScene().getWindow();
    	  scene = new Scene(root);
    	  stage.setScene(scene);
    	  stage.show();
  }
  @FXML
  void SwitchToStocks(ActionEvent event) throws IOException {
  	  root = FXMLLoader.load(getClass().getResource("liste_de_stock.fxml"));
    	  stage = (Stage)((Node)event.getSource()).getScene().getWindow();
    	  scene = new Scene(root);
    	  stage.setScene(scene);
    	  stage.show();
  }

  @FXML
  void SwitchToTransactions(ActionEvent event) throws IOException {
  	  root = FXMLLoader.load(getClass().getResource("liste_des_transactions.fxml"));
    	  stage = (Stage)((Node)event.getSource()).getScene().getWindow();
    	  scene = new Scene(root);
    	  stage.setScene(scene);
    	  stage.show();
  }
}
