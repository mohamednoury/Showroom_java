package application;

import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import model.liste_employes;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class edit_employe_controller {

    @FXML
    private Button enregistrer;

    @FXML
    private TextField nom;

    @FXML
    private Label ID;

    @FXML
    private TextField prenom;

    @FXML
    private TextField addresse;

    @FXML
    private TextField cin;

    @FXML
    private TextField telephone;

    @FXML
    private TextField salaire;

    @FXML
    private ChoiceBox<String> departement; // Corrected the type parameter

    private liste_employes originalData;
    private Connection connection;

    public void initializeData(liste_employes list) {
        this.originalData = list;
        ID.setText(String.valueOf(list.getId()));
        nom.setText(list.getNom());
        prenom.setText(list.getPrenom());
        cin.setText(list.getCin());
        addresse.setText(list.getAdresse());
        telephone.setText(list.getTelephone());
        departement.setValue(list.getDepartement());
        salaire.setText(String.valueOf(list.getSalaire()));
    }

    @FXML
    void UpdateStock() {
        try {
            originalData.setId(Integer.parseInt(ID.getText()));
            originalData.setNom(nom.getText());
            originalData.setPrenom(prenom.getText());
            originalData.setCin(cin.getText());
            originalData.setAdresse(addresse.getText());
            originalData.setTelephone(telephone.getText());
            originalData.setDepartement(departement.getValue());
            originalData.setSalaire(Double.parseDouble(salaire.getText()));
        } catch (NumberFormatException e) {
            e.printStackTrace(); // Handle parsing errors
        }

        updateDatabase(originalData);

        // Close the edit view
        Stage stage = (Stage) enregistrer.getScene().getWindow();
        stage.close();
    }

    private void updateDatabase(liste_employes updatedData) {
        try {
            connection = MysqlConnection.getDBConnection();
            connection.setAutoCommit(false);

            String sql = "UPDATE employes SET nom=?, prenom=?, cin=?, adresse=?, numero_telephone=?, departement=?, salaire=? WHERE id=?";
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setString(1, updatedData.getNom());
                statement.setString(2, updatedData.getPrenom());
                statement.setString(3, updatedData.getCin());
                statement.setString(4, updatedData.getAdresse());
                statement.setString(5, updatedData.getTelephone());
                statement.setString(6, updatedData.getDepartement());
                statement.setDouble(7, updatedData.getSalaire());
                statement.setInt(8, updatedData.getId());

                statement.executeUpdate();
            }

            connection.commit();
        } catch (SQLException e) {
            e.printStackTrace();
            try {
                if (connection != null) {
                    connection.rollback();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        } finally {
            try {
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }
    
    private Stage stage;
	 private Scene scene;
	 private Parent root;
   
	 
	@FXML
	    private Button annuler;
	
	 
   @FXML
   void SwitchToliste(ActionEvent event) throws IOException {
	   // Get the current stage
	   Stage stage = (Stage) annuler.getScene().getWindow();
       stage.close();
   }
}
