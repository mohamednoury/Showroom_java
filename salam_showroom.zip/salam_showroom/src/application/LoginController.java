package application;

import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import javafx.scene.control.Button;
import javafx.scene.control.Alert;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.fxml.FXMLLoader;
import javafx.stage.Stage;

import java.lang.ModuleLayer.Controller;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;


public class LoginController {

    @FXML
    private TextField emailTextField;

    @FXML
    private TextField passwordTextField;

    @FXML
    private Button connectButton;

    private Stage stage;
    private Scene scene;
    private Parent root;

    public void initialize() {
        connectButton.setOnAction(event -> attemptLogin());
    }

    public void attemptLogin() {
        String email = emailTextField.getText();
        String password = passwordTextField.getText();
        String nomComplet = checkCredentials(email, password);

        if (nomComplet != null) {
            loadDashboard(email, nomComplet);
        } else {
            // Optionally, display an error message
            showAlert("Login Failed", "Incorrect email or password.");
        }
    }

    private String checkCredentials(String email, String password) {
        // Database URL, username and password
        String url = "jdbc:mysql://localhost:3306/showroom";
        String user = "root";
        String pass = "";
        String nomComplet = null;
        String sql = "SELECT * FROM user WHERE email = ? AND password = ?";

        try (Connection conn = DriverManager.getConnection(url, user, pass);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, email);
            pstmt.setString(2, password);

            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                nomComplet = rs.getString("nom_complet");
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return nomComplet;

    }

    private void loadDashboard(String email, String nomComplet) {
        try {
        	FXMLLoader loader = new FXMLLoader(getClass().getResource("dashboardVoiture.fxml"));
            Parent root = loader.load();
            
            // R�cup�rer le contr�leur du tableau de bord
            controller dashboardController = loader.getController();
            
            // Passer l'e-mail et le nom complet au contr�leur du tableau de bord
            dashboardController.setUserDetails(email, nomComplet);

            Stage stage = (Stage) connectButton.getScene().getWindow();
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}