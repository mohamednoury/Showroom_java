package application;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import model.liste_clients;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class edit_client_controller {

    @FXML
    private Label id;

    @FXML
    private Button enregistrer;

    @FXML
    private TextField nom;

    @FXML
    private TextField prenom;

    @FXML
    private TextField cin;

    @FXML
    private TextField addresse;

    @FXML
    private TextField telephone;

    private liste_clients data = new liste_clients(); // Initialize data variable

    
    private liste_clients originalData;
    
    private Connection connection;

    public void initializeData(liste_clients list) {
        this.originalData = list;
        id.setText(String.valueOf(list.getId()));
    	nom.setText(list.getNom());
    	prenom.setText(list.getPrenom());
    	cin.setText(list.getCin());
    	addresse.setText(list.getAdresse());
    	telephone.setText(list.getTelephone());
    }

    @FXML
    void UpdateStock() {
        try {
            // Update data object with new values
        	
        	data.setId(Integer.parseInt(id.getText()));
        	data.setNom(nom.getText());  // Use String directly, no need for String.parseString
        	data.setPrenom(prenom.getText());  // Use String directly
        	data.setCin(cin.getText());  // Remove extra ')' here
        	data.setAdresse(addresse.getText());  // Remove extra ')' here
        	data.setTelephone(telephone.getText());  // Remove extra ')' here

        } catch (NumberFormatException e) {
            // Handle parsing errors (e.g., invalid double format)
            // You might want to show an error message to the user
        }
        updateDatabase(data);

        
        // Close the edit view
        Stage stage = (Stage) enregistrer.getScene().getWindow();
        stage.close();
    
    }

    private void updateDatabase(liste_clients updatedData) {
        try {
            connection = MysqlConnection.getDBConnection(); // Initialize the connection
            connection.setAutoCommit(false);  // Set auto-commit to false

            String sql = "UPDATE cLients SET nom=?, prenom=?, cin=?, adresse=? ,numero_telephone=? WHERE id=?";
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setString(1, updatedData.getNom());
                statement.setString(2, updatedData.getPrenom());
                statement.setString(3, updatedData.getCin());       
                statement.setString(4, updatedData.getAdresse());
                statement.setString(5, updatedData.getTelephone());
                statement.setInt(6, updatedData.getId());

                statement.executeUpdate();
            }

            // Commit the transaction
            connection.commit();
        } catch (SQLException e) {
            e.printStackTrace(); // Handle the exception according to your application's requirements

            // Rollback the transaction if needed
            try {
                if (connection != null) {
                    connection.rollback();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        } finally {
            // Close the connection in the finally block to ensure it's closed even if an exception occurs
            try {
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }
    
    private Stage stage;
	 private Scene scene;
	 private Parent root;
   
	 
	@FXML
	    private Button annuler;
	
	 
   @FXML
   void SwitchToliste(ActionEvent event) throws IOException {
	   Stage stage = (Stage) annuler.getScene().getWindow();
       stage.close();
   }
}
