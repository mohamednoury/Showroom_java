package application;

import java.io.FileWriter;
import java.io.IOException;
import java.io.Serializable;
import java.net.URL;
import java.rmi.AccessException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.ResourceBundle;
import java.util.stream.Collectors;

import javax.swing.text.html.ImageView;
import javax.swing.tree.DefaultTreeCellEditor.DefaultTextField;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import model.liste;
import model.liste_clients;

public class liste_client_controller implements Initializable{

	  @FXML
	    private VBox listelayout;
	  @FXML
	  private TextField searchByIdField;
	  @FXML
	  private TextField searchByNomField;
	  @FXML
	  private TextField searchByPrenomField;
	  @FXML
	  private TextField searchByCINField;
	  @FXML
	  private TextField searchByAdresseField;
	  @FXML
	  private TextField searchByTelephoneField;
	  
	  


	  @Override
	    public void initialize (URL location, ResourceBundle resources) {
		  
		  loadClients(); // Assurez-vous que cette m�thode existe dans votre contr�leur

  	List <liste_clients> listesFromDatabase = new ArrayList<>(listesFromDatabase());
  	for (int i = 0 ; i<listesFromDatabase.size() ; i++) {
  		FXMLLoader fxmlloader = new FXMLLoader ();
  		fxmlloader.setLocation(getClass().getResource("ithem_client.fxml"));
  		
  		try {
  			HBox hBox = fxmlloader.load();
  			ithem_client_controller cic = fxmlloader.getController();
  			cic.setData(listesFromDatabase.get(i));
  			listelayout.getChildren().add(hBox);
  		
  			
  		}catch (IOException e) {
  			e.printStackTrace();
  		}
  		
  	}
  	searchByIdField.textProperty().addListener((observable, oldValue, newValue) -> {
         searchClientById(newValue);
         }
     );
  	searchByNomField.textProperty().addListener((observable, oldValue, newValue) -> {
  		searchClientByNom(newValue);
     });

  	searchByPrenomField.textProperty().addListener((observable, oldValue, newValue) -> {
  		searchClientByPrenom(newValue);
     });

  	searchByCINField.textProperty().addListener((observable, oldValue, newValue) -> {
  		searchClientByCin(newValue);
     });

  	searchByAdresseField.textProperty().addListener((observable, oldValue, newValue) -> {
  		searchClientByAddresse(newValue);
     });
  	
  	searchByTelephoneField.textProperty().addListener((observable, oldValue, newValue) -> {
  		searchClientByPhone(newValue);
    });
  }  
	    
	  private List<liste_clients> listesFromDatabase() {
		    List<liste_clients> ls = new ArrayList<>();

		    try {
		        Connection connection = MysqlConnection.getDBConnection();

		        String sql = "SELECT * FROM `clients`";
		        try (PreparedStatement ps = connection.prepareStatement(sql);
		             ResultSet results = ps.executeQuery()) {

		            while (results.next()) {
		                int id = results.getInt("id");
		                String nom = results.getString("nom");
		                String prenom = results.getString("prenom");
		                String cin = results.getString("cin");
		                String adresse = results.getString("adresse");
		                String telephone = results.getString("numero_telephone");

		                liste_clients list = new liste_clients();
		                list.setId(id);
		                list.setNom(nom);
		                list.setPrenom(prenom);
		                list.setCin(cin);
		                list.setAdresse(adresse);
		                list.setTelephone(telephone);

		                ls.add(list);
		            }
		        }
		    } catch (SQLException e) {
		        e.printStackTrace(); // Handle exceptions appropriately, you may log or throw a custom exception
		    }

		    return ls;
		}
	  
	  @FXML
	  private void refreshData(ActionEvent event) {
		  loadClients(); // Assurez-vous que cette m�thode existe dans votre contr�leur
	  }
	  
		 private Stage stage;
		 private Scene scene;
		 private Parent root;
	   
	   
		   
		   @FXML
		   void SwitchToAddProduit(ActionEvent event) throws IOException {
		 	  root = FXMLLoader.load(getClass().getResource("nouv_vehicule.fxml"));
		 	  stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		 	  scene = new Scene(root);
		 	  stage.setScene(scene);
		 	  stage.show();
		   }
		   
		   @FXML
		   void SwitchToAddClient(ActionEvent event) throws IOException {
		 	  root = FXMLLoader.load(getClass().getResource("addClient.fxml"));
		 	  stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		 	  scene = new Scene(root);
		 	  stage.setScene(scene);
		 	  stage.show();
		   }
		   @FXML
		   void SwitchToAddTransaction(ActionEvent event) throws IOException {
		 	  root = FXMLLoader.load(getClass().getResource("nouv_trans.fxml"));
		 	  stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		 	  scene = new Scene(root);
		 	  stage.setScene(scene);
		 	  stage.show();
		   }

		   @FXML
		   void SwitchToAddVehicule(ActionEvent event) throws IOException {
		   	  root = FXMLLoader.load(getClass().getResource("nouv_vehicule.fxml"));
		     	  stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		     	  scene = new Scene(root);
		     	  stage.setScene(scene);
		     	  stage.show();
		   }

		   @FXML
		   void SwitchToClients(ActionEvent event) throws IOException {
		   	  root = FXMLLoader.load(getClass().getResource("liste_des_clients.fxml"));
		     	  stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		     	  scene = new Scene(root);
		     	  stage.setScene(scene);
		     	  stage.show();
		   }
		   
		  

		   @FXML
		   void SwitchToDashboard(ActionEvent event) throws IOException {
		   	  root = FXMLLoader.load(getClass().getResource("dashboardVoiture.fxml"));
		     	  stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		     	  scene = new Scene(root);
		     	  stage.setScene(scene);
		     	  stage.show();
		   }

		   @FXML
		   void SwitchToEmploye(ActionEvent event) throws IOException {
		   	  root = FXMLLoader.load(getClass().getResource("liste_des_employes.fxml"));
		     	  stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		     	  scene = new Scene(root);
		     	  stage.setScene(scene);
		     	  stage.show();
		   }
		   @FXML
		   void SwitchToStocks(ActionEvent event) throws IOException {
		   	  root = FXMLLoader.load(getClass().getResource("liste_de_stock.fxml"));
		     	  stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		     	  scene = new Scene(root);
		     	  stage.setScene(scene);
		     	  stage.show();
		   }

		   @FXML
		   void SwitchToTransactions(ActionEvent event) throws IOException {
		   	  root = FXMLLoader.load(getClass().getResource("liste_des_transactions.fxml"));
		     	  stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		     	  scene = new Scene(root);
		     	  stage.setScene(scene);
		     	  stage.show();
		   }
		   @FXML
		   private void exportClientsToCSV() {
		       String csvFilePath = "clients.csv";

		       try (FileWriter fileWriter = new FileWriter(csvFilePath)) {
		           Connection connection = MysqlConnection.getDBConnection();
		           String sql = "SELECT * FROM clients";
		           Statement statement = connection.createStatement();
		           ResultSet resultSet = statement.executeQuery(sql);

		           // Write Column Headers
		           fileWriter.append("id,nom,prenom,cin,adresse,numero_telephone\n");

		           // Write Data
		           while (resultSet.next()) {
		               fileWriter.append(String.valueOf(resultSet.getInt("id"))).append(",");
		               fileWriter.append(resultSet.getString("nom")).append(",");
		               fileWriter.append(resultSet.getString("prenom")).append(",");
		               fileWriter.append(resultSet.getString("cin")).append(",");
		               fileWriter.append(resultSet.getString("adresse")).append(",");
		               fileWriter.append(resultSet.getString("numero_telephone")).append("\n");
		           }
		       } catch (IOException | SQLException e) {
		           e.printStackTrace(); // Handle exceptions
		       }
		   }

		   private void searchClientById(String searchText) {
			    if (searchText.isEmpty()) {
			        loadClients(); // Load all clients if search text is empty
			        return;
			    }

			    int searchId;
			    try {
			        searchId = Integer.parseInt(searchText);
			    } catch (NumberFormatException e) {
			        // Handle invalid input (not a number)
			        loadClients(); // Load all clients if input is invalid
			        return;
			    }

			    List<liste_clients> filteredClients = listesFromDatabase().stream()
			        .filter(client -> client.getId() == searchId)
			        .collect(Collectors.toList());

			    updateClientList(filteredClients);
			}

		   private void searchClientByPhone(String phone) {
			    if (phone.isEmpty()) {
			        loadClients(); // Load all clients if phone is empty
			        return;
			    }

			    List<liste_clients> filteredClients = listesFromDatabase().stream()
			        .filter(client -> client.getTelephone().toLowerCase().contains(phone.toLowerCase()))
			        .collect(Collectors.toList());

			    updateClientList(filteredClients);
			}



			private void searchClientByAddresse(String adresse) {
			    List<liste_clients> filteredClients = listesFromDatabase().stream()
			        .filter(client -> client.getAdresse().toLowerCase().contains(adresse.toLowerCase()))
			        .collect(Collectors.toList());

			    updateClientList(filteredClients);
			}

			private void searchClientByCin(String cin) {
			    List<liste_clients> filteredClients = listesFromDatabase().stream()
			        .filter(client -> client.getCin().toLowerCase().contains(cin.toLowerCase()))
			        .collect(Collectors.toList());

			    updateClientList(filteredClients);
			}

			private void searchClientByPrenom(String prenom) {
			    List<liste_clients> filteredClients = listesFromDatabase().stream()
			        .filter(client -> client.getPrenom().toLowerCase().contains(prenom.toLowerCase()))
			        .collect(Collectors.toList());

			    updateClientList(filteredClients);
			}

			private void searchClientByNom(String nom) {
			    List<liste_clients> filteredClients = listesFromDatabase().stream()
			        .filter(client -> client.getNom().toLowerCase().contains(nom.toLowerCase()))
			        .collect(Collectors.toList());

			    updateClientList(filteredClients);
			}


			private void loadClients() {
			    List<liste_clients> allClients = listesFromDatabase();
			    updateClientList(allClients);
			}

			private void updateClientList(List<liste_clients> clients) {
			    listelayout.getChildren().clear(); // Clear current contents
			    for (liste_clients client : clients) {
			        FXMLLoader fxmlLoader = new FXMLLoader();
			        fxmlLoader.setLocation(getClass().getResource("ithem_client.fxml"));
			        try {
			            HBox hBox = fxmlLoader.load();
			            ithem_client_controller controller = fxmlLoader.getController();
			            controller.setData(client);
			            listelayout.getChildren().add(hBox);
			        } catch (IOException e) {
			            e.printStackTrace(); // Proper exception handling should be implemented
			        }
			    }
			}


}