package application;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import model.liste;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Delete_transaction_controller {

    @FXML
    private Label id;

    @FXML
    private TextField id_vehicule;

    @FXML
    private TextField id_client;

    @FXML
    private TextField montant;

    @FXML
    private TextField date;

    private liste data;

    private liste originalData;

    @FXML
    private Button delete;

    public void setData(liste data) {
        this.data = data;
        // Set the values to your UI elements if needed
    }
    
    @FXML
    void DeleteTransaction(ActionEvent event) {
        int Id = this.data.getId_transaction();

    	 try {
    	        // Your code to delete information from the database

        // Get a connection to the database
        Connection connection = MysqlConnection.getDBConnection(); // Replace YourDatabaseUtil with your database connection utility
        
        try {
            // Prepare the DELETE SQL query
            String deleteQuery = "DELETE FROM transactions WHERE Id = ?"; // Replace your_table_name with your actual table name
            PreparedStatement preparedStatement = connection.prepareStatement(deleteQuery);
            preparedStatement.setInt(1, data.getId_transaction()); // Assuming getId_transaction() gets the ID of the transaction

            // Execute the query to delete the record
            int rowsDeleted = preparedStatement.executeUpdate();

            if (rowsDeleted > 0) {
                System.out.println("Record deleted successfully!");
            } else {
                System.out.println("Record not found or unable to delete.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            // Close the database connection
        	MysqlConnection.closeConnection(connection); // Replace YourDatabaseUtil with your database connection utility
        }
    	 } catch (SQLException e) {
 	        // Handle the SQLException
 	        e.printStackTrace(); // You can log the exception or show an error message
 	    }

        // Close the stage
        Stage stage = (Stage) delete.getScene().getWindow();
        stage.close();
    }
    
    
    @FXML
    private Button annuler;

 
@FXML
void SwitchToliste(ActionEvent event) throws IOException {
   // Get the current stage
   Stage stage = (Stage) annuler.getScene().getWindow();
   stage.close();
}
   
	  

    
    
}
