package application;

public class vehicle {
    private String marque;
    private String modele;
    private int prixAchatVehicule;
    private int prixVenteVehicule;
    private int anneeDeSortie;
    private int quantiteVehicule;
    private String statusVehicule;

    public vehicle(String marque, String modele, int prixAchatVehicule, int prixVenteVehicule, int anneeDeSortie, int quantiteVehicule, String statusVehicule){
        this.marque = marque;
        this.modele = modele;
        this.prixAchatVehicule = prixAchatVehicule;
        this.prixVenteVehicule = prixVenteVehicule;
        this.anneeDeSortie = anneeDeSortie;
        this.quantiteVehicule = quantiteVehicule;
        this.statusVehicule = statusVehicule;
    }

    public String getmarque() {
        return marque;
    }

    public void setmarque(String marque) {
        this.marque = marque;
    }

    public String getmodele() {
        return modele;
    }

    public void setmodele(String modele) {
        this.modele = modele;
    }

    public int getprixAchatVehicule() {
        return prixAchatVehicule;
    }

    public void setprixAchatVehicule(int prixAchatVehicule) {
        this.prixAchatVehicule = prixAchatVehicule;
    }

    public int getprixVenteVehicule() {
        return prixVenteVehicule;
    }

    public void setprixVenteVehicule(int prixVenteVehicule) {
        this.prixVenteVehicule = prixVenteVehicule;
    }

    public int getanneeDeSortie() {
        return anneeDeSortie;
    }

    public void setanneeDeSortie(int anneeDeSortie) {
        this.anneeDeSortie = anneeDeSortie;
    }

    public int getquantiteVehicule() {
        return quantiteVehicule;
    }

    public void setquantiteVehicule(int quantiteVehicule) {
        this.quantiteVehicule = quantiteVehicule;
    }

    public String getstatusVehicule() {
        return statusVehicule;
    }

    public void setstatusVehicule(String statusVehicule) {
        this.statusVehicule = statusVehicule;
    }
}
