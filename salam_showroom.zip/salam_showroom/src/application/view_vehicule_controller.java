package application;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;  // Corrected import statement
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import model.liste_vehicule;

public class view_vehicule_controller {

    @FXML
    private Label ID;

    @FXML
    private ImageView img;

    @FXML
    private Label marqu;

    @FXML
    private Label model;

    @FXML
    private Label prixAchatVehicul;

    @FXML
    private Label prixVenteVehicul;

    @FXML
    private Label annesorti;

    @FXML
    private Label quantiteVehicul;

    @FXML
    private Label statusVehicul;
    

    public void setData(liste_vehicule list) {
    	marqu.setText(list.getMarque());

        ID.setText(String.valueOf(list.getId()));
        annesorti.setText(list.getDate_sortie());
        prixVenteVehicul.setText(String.valueOf(list.getPrix_vente()));
        prixAchatVehicul.setText(String.valueOf(list.getPrix_achat()));
        model.setText(list.getModele());
        quantiteVehicul.setText(String.valueOf(list.getQuantite()));
        statusVehicul.setText(list.getStatus());

        if (list.getImagePath() != null && !list.getImagePath().isEmpty()) {
            try {
                Image image = new Image(new FileInputStream(list.getImagePath()));
                img.setImage(image);
            } catch (FileNotFoundException e) {
                System.err.println("Error loading image: " + list.getImagePath());
                e.printStackTrace();
            }
        }
    }

    @FXML
    private Button annuler;
    
    private Stage stage;
	 private Scene scene;
	 private Parent root;
 

	 
	 private static boolean viewVehiculeOpen = false;

	    // ...

	    @FXML
	    void SwitchToliste(ActionEvent event) throws IOException {
	        if (!viewVehiculeOpen) {
	            // Charger la fen�tre principale (liste_de_stock.fxml)
	            FXMLLoader loader = new FXMLLoader(getClass().getResource("liste_de_stock.fxml"));
	            Parent root = loader.load();

	            // Cr�er une nouvelle sc�ne et un nouveau stage pour la fen�tre principale
	            Stage mainStage = new Stage();
	            Scene scene = new Scene(root);
	            mainStage.setScene(scene);

	            // Configurer la modalit� de la fen�tre principale
	            mainStage.initModality(Modality.APPLICATION_MODAL);

	            // Ajouter un �couteur pour intercepter la fermeture de la fen�tre principale
	            mainStage.setOnCloseRequest(e -> viewVehiculeOpen = false);

	            // Afficher la fen�tre principale sans attendre
	            mainStage.show();

	            // Marquer la fen�tre view_vehicule comme ouverte
	            viewVehiculeOpen = true;

	            // Fermer la fen�tre actuelle (view_vehicule)
	            Stage currentStage = (Stage) annuler.getScene().getWindow();
	            currentStage.close();
	        }
	    }




    
}
