package application;

import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.stage.Stage;
import model.liste_clients;

public class view_client_controller {

    @FXML
    private Label id;

    @FXML
    private Label nom;

    @FXML
    private Label prenom;

    @FXML
    private Label cin;

    @FXML
    private Label addresse;

    @FXML
    private Label telephone;
 

    public void setData(liste_clients list) {
        id.setText(String.valueOf(list.getId()));
        nom.setText(list.getNom());
        prenom.setText(list.getPrenom());
        addresse.setText(list.getAdresse());
        cin.setText(list.getCin());
        telephone.setText(list.getTelephone());
    }
    
    private Stage stage;
	 private Scene scene;
	 private Parent root;
    
	 
	@FXML
	    private Button annuler;
	
	 
    @FXML
    void SwitchToliste(ActionEvent event) throws IOException {
    	 Stage stage = (Stage) annuler.getScene().getWindow();
         stage.close();
    }
}
