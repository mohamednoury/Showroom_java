package application;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.stage.Modality;
import javafx.stage.Stage;
import model.liste_clients;
import model.liste_employes;
import javafx.scene.control.Label;


	public class ithem_employe_controller implements Initializable {

		@FXML
	    private Label id;

	    @FXML
	    private Label nom;

	    @FXML
	    private Label prenom;

	    @FXML
	    private Label cin;

	    @FXML
	    private Label addresse;

	    @FXML
	    private Label telephone;

	    @FXML
	    private Label departement;

	    @FXML
	    private Label salaire;

	    private liste_employes data; 

	    public void setData(liste_employes list) {
	        this.data = list;
	        id.setText(String.valueOf(list.getId()));
	        nom.setText(list.getNom());
	        prenom.setText(list.getPrenom());
	        addresse.setText(list.getAdresse());
	        cin.setText(list.getCin());
	        telephone.setText(list.getTelephone());
	        departement.setText(list.getDepartement());
	        salaire.setText(String.valueOf(list.getSalaire()));
	    }
	    
		 
		    
		    private Stage stage;
		    private Scene scene;
		    private Parent root;
		    
		    
		    @FXML
		    private Button view_client;
		    
		    
		    
		    
		    @FXML
		    void SwitchToViewEmploye(ActionEvent event) throws IOException {
		        FXMLLoader loader = new FXMLLoader(getClass().getResource("view_employe.fxml"));
		        Parent root = loader.load();

		        view_employe_controller viewController = loader.getController();
		        viewController.setData(data); // Pass the selected transaction data

		        // Cr�er une nouvelle sc�ne
		        Scene scene = new Scene(root);

		        // Cr�er une nouvelle fen�tre modale
		        Stage newStage = new Stage();
		        newStage.setScene(scene);
		        newStage.setX(300);
		        newStage.setY(155);
		        newStage.initModality(Modality.APPLICATION_MODAL);
		        newStage.showAndWait(); // Bloque l'ex�cution jusqu'� ce que la fen�tre soit ferm�e

		        // Le code ici sera ex�cut� apr�s la fermeture de la fen�tre view_vehicule

		        // Vous pouvez �galement actualiser les donn�es de la fen�tre actuelle ici, si n�cessaire
		    }


		    
		    @FXML
		    private Button edit_employe;

		    @FXML
		    void SwitchToEditEmploye(ActionEvent event) throws IOException {
		        FXMLLoader loader = new FXMLLoader(getClass().getResource("edit_employe.fxml"));
		        Parent root = loader.load();

		        edit_employe_controller editController = loader.getController();
		        editController.initializeData(data); // Pass the selected transaction data

		        Stage stage = new Stage();
		        Scene scene = new Scene(root);
		        stage.setScene(scene);
		        stage.setX(300);
		        stage.setY(155);
		        stage.initModality(Modality.APPLICATION_MODAL);
		        stage.showAndWait();
		    }
		    
		    @FXML
		    private Button Delete_employe;
		   
		    @FXML
		    void SwitchToDeleteEmploye(ActionEvent event) throws IOException {
		        FXMLLoader loader = new FXMLLoader(getClass().getResource("Delete_employe.fxml"));
		        Parent root = loader.load();

		        Delete_employe_controller deleteController = loader.getController();
		        deleteController.setData(data); // Pass the selected transaction data

		        Stage stage = new Stage();
		        Scene scene = new Scene(root);
		        stage.setScene(scene);
		        stage.setX(530);
		        stage.setY(350);
		        stage.initModality(Modality.APPLICATION_MODAL);
		        stage.showAndWait();
		    }
		    
		    @Override 
		    public void initialize (URL location, ResourceBundle resources) {
		    	
		    }
		   
	}

	
	