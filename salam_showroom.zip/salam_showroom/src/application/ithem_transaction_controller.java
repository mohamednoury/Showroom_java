package application;

import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ResourceBundle;
import javax.swing.text.html.ImageView;
import java.sql.SQLException;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;
import model.liste;

public class ithem_transaction_controller implements Initializable {

	    @FXML
	    private Label id_transaction;

	    @FXML
	    private Label id_vehicule;

	    @FXML
	    private Label id_client;

	    @FXML
	    private Label date;

	    @FXML
	    private Label mantant;
	    	    
	    private liste data; // Declare data variable
	    
	    public void setData(liste list) {
	        this.data = list;
	        id_transaction.setText(String.valueOf(list.getId_transaction()));
	        id_vehicule.setText(String.valueOf(list.getId_vehicule()));
	        id_client.setText(String.valueOf(list.getId_client()));
	        date.setText(list.getDate().toString());
	        mantant.setText(String.valueOf(list.getMantant()));
	    }
	    
	    
	    @FXML
	    private Button view_transaction;

	    private Stage stage;
	    private Scene scene;
	    private Parent root;

	    
	    @FXML
	    void SwitchToViewTransaction(ActionEvent event) throws IOException {
	        FXMLLoader loader = new FXMLLoader(getClass().getResource("view_transaction.fxml"));
	        Parent root = loader.load();

	        view_transaction_controller viewController = loader.getController();
	        viewController.setData(data); // Pass the selected vehicule data

	        Stage stage = new Stage();
	        Scene scene = new Scene(root);
	        stage.setScene(scene);
	        stage.initModality(Modality.APPLICATION_MODAL); // Set modality before showing the stage
	        stage.setX(450);
	        stage.setY(250);
	        stage.showAndWait();
	    }

	    
	    
	    @FXML
	    private Button edit_transaction;

	    @FXML
	    void SwitchToEditTransaction(ActionEvent event) throws IOException {
	        FXMLLoader loader = new FXMLLoader(getClass().getResource("edit_transaction.fxml"));
	        Parent root = loader.load();

	        edit_transaction_controller editController = loader.getController();
	        editController.initializeData(data); // Pass the selected transaction data

	        Stage stage = new Stage();
	        Scene scene = new Scene(root);
	        stage.setScene(scene);
	        stage.initModality(Modality.APPLICATION_MODAL); // Set modality before showing the stage
	        stage.setX(450);
	        stage.setY(250);
	        stage.showAndWait();
	    }
	    
	    
	    //////	   
	    
	    @FXML
	    private Button Delete_Transaction;
	   
	    @FXML
	    void SwitchToDeleteTransaction(ActionEvent event) throws IOException {
	        FXMLLoader loader = new FXMLLoader(getClass().getResource("Delete_transaction.fxml"));
	        Parent root = loader.load();

	        Delete_transaction_controller deleteController = loader.getController();
	        deleteController.setData(data); // Pass the selected transaction data

	        Stage stage = new Stage();
	        Scene scene = new Scene(root);
	        stage.setScene(scene);
	        stage.setX(530);
	        stage.setY(350);
	        stage.initModality(Modality.APPLICATION_MODAL);
	        stage.showAndWait();
	    }

	    
	    
	   
	    
	    @Override 
	    public void initialize (URL location, ResourceBundle resources) {
	    	
	    }
	   
}

