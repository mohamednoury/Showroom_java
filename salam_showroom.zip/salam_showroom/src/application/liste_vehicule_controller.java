package application;

import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.image.Image;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import model.liste;
import model.liste_clients;
import model.liste_vehicule;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;


public class liste_vehicule_controller implements Initializable {

	   @FXML
	    private TextField rechercheMarque;

	    @FXML
	    private TextField rechercheModele;

	    @FXML
	    private TextField recherchePrixAchat;

	    @FXML
	    private TextField recherchePrixVente;

	    @FXML
	    private TextField rechercheQuantite;

	    @FXML
	    private TextField rechercheId;

	    @FXML
	    private TextField rechercheStatus;
    @FXML
    private VBox liste_vehicule_layout;
    
    
    @Override
    public void initialize(URL location, ResourceBundle resources) {
        List<liste_vehicule> listesFromDatabase = new ArrayList<>(listesFromDatabase());
        for (int i = 0; i < listesFromDatabase.size(); i++) {
            FXMLLoader fxmlloader = new FXMLLoader();
            fxmlloader.setLocation(getClass().getResource("ithem_vehicule.fxml"));

            try {
                HBox hBox = fxmlloader.load();
                ithem_stock_controller cics = fxmlloader.getController();
                cics.setData(listesFromDatabase.get(i));
                liste_vehicule_layout.getChildren().add(hBox);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        rechercheMarque.textProperty().addListener((observable, oldValue, newValue) -> {
        	searchInDatabase();
        });

        rechercheModele.textProperty().addListener((observable, oldValue, newValue) -> {
        	searchInDatabase();
        });

        recherchePrixAchat.textProperty().addListener((observable, oldValue, newValue) -> {
        	searchInDatabase();
        });

        recherchePrixVente.textProperty().addListener((observable, oldValue, newValue) -> {
        	searchInDatabase();
        });

        rechercheQuantite.textProperty().addListener((observable, oldValue, newValue) -> {
        	searchInDatabase();
        });

        rechercheId.textProperty().addListener((observable, oldValue, newValue) -> {
        	searchInDatabase();
        });

        rechercheStatus.textProperty().addListener((observable, oldValue, newValue) -> {
        	searchInDatabase();
        });
    }
   

    
    @FXML
	  private void refreshData(ActionEvent event) {
		  loadVehicule(); // Assurez-vous que cette m�thode existe dans votre contr�leur
	  }

    
    private void loadVehicule() {
        List<liste_vehicule> allVehicule = listesFromDatabase();
        updateVehiculeList(allVehicule);
    }
    
   
    private void updateVehiculeList(List<liste_vehicule> vehicules) {
        liste_vehicule_layout.getChildren().clear(); // Supprime tous les �l�ments actuels de la liste

        for (liste_vehicule vehicule : vehicules) {
            FXMLLoader fxmlloader = new FXMLLoader();
            fxmlloader.setLocation(getClass().getResource("ithem_vehicule.fxml"));

            try {
                HBox hBox = fxmlloader.load();
                ithem_stock_controller cics = fxmlloader.getController();
                cics.setData(vehicule);
                liste_vehicule_layout.getChildren().add(hBox);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

	  

    private List<liste_vehicule> listesFromDatabase() {
        List<liste_vehicule> ls = new ArrayList<>();

       
        try {
            Connection connection = MysqlConnection.getDBConnection();
            String sql = "SELECT * FROM stocks";
            try (PreparedStatement ps = connection.prepareStatement(sql);
                    ResultSet results = ps.executeQuery()) {
                while (results.next()) {

                	

                    int id = results.getInt("Id");
                    String Marque = results.getString("Marque");
                    String modele = results.getString("modele");
                    double prix_achat = results.getDouble("prix_achat");
                    double prix_vente = results.getDouble("prix_vente");
                    int quantite = results.getInt("quantite");
                    String Date_sortie = results.getString("Date_sortie");
                    String status = results.getString("status");
                    String imagePath = results.getString("vehicule_image_path");  

                    
                    liste_vehicule list = new liste_vehicule();
                    list.setId(id);
                    list.setMarque(Marque);
                    list.setModele(modele);
                    list.setPrix_achat(prix_achat);
                    list.setPrix_vente(prix_vente);
                    list.setQuantite(quantite);
                    list.setDate_sortie(Date_sortie);
                    list.setStatus(status);
                    list.setImagePath(imagePath);         
                
                    ls.add(list);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace(); // Handle exceptions appropriately, you may log or throw a custom exception
        }

        return ls;
    }
	 private Stage stage;
	 private Scene scene;
	 private Parent root;
    
    
    @FXML
    void SwitchToAddProduit(ActionEvent event) throws IOException {
  	  root = FXMLLoader.load(getClass().getResource("nouv_vehicule.fxml"));
  	  stage = (Stage)((Node)event.getSource()).getScene().getWindow();
  	  scene = new Scene(root);
  	  stage.setScene(scene);
  	  stage.show();
    }

    @FXML
    void SwitchToAddVehicule(ActionEvent event) throws IOException {
    	  root = FXMLLoader.load(getClass().getResource("nouv_vehicule.fxml"));
      	  stage = (Stage)((Node)event.getSource()).getScene().getWindow();
      	  scene = new Scene(root);
      	  stage.setScene(scene);
      	  stage.show();
    }

    @FXML
    void SwitchToClients(ActionEvent event) throws IOException {
    	  root = FXMLLoader.load(getClass().getResource("liste_des_clients.fxml"));
      	  stage = (Stage)((Node)event.getSource()).getScene().getWindow();
      	  scene = new Scene(root);
      	  stage.setScene(scene);
      	  stage.show();
    }

    @FXML
    void SwitchToDashboard(ActionEvent event) throws IOException {
    	  root = FXMLLoader.load(getClass().getResource("dashboardVoiture.fxml"));
      	  stage = (Stage)((Node)event.getSource()).getScene().getWindow();
      	  scene = new Scene(root);
      	  stage.setScene(scene);
      	  stage.show();
    }

    @FXML
    void SwitchToEmploye(ActionEvent event) throws IOException {
    	  root = FXMLLoader.load(getClass().getResource("liste_des_employes.fxml"));
      	  stage = (Stage)((Node)event.getSource()).getScene().getWindow();
      	  scene = new Scene(root);
      	  stage.setScene(scene);
      	  stage.show();
    }

    @FXML
    void SwitchToTransactions(ActionEvent event) throws IOException {
    	  root = FXMLLoader.load(getClass().getResource("liste_des_transactions.fxml"));
      	  stage = (Stage)((Node)event.getSource()).getScene().getWindow();
      	  scene = new Scene(root);
      	  stage.setScene(scene);
      	  stage.show();
    }
    @FXML
    private void exportStocksToCSV() {
        String csvFilePath = "stocks.csv";

        try (FileWriter fileWriter = new FileWriter(csvFilePath)) {
            Connection connection = MysqlConnection.getDBConnection();
            String sql = "SELECT * FROM stocks";
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(sql);

            // Write Column Headers
            fileWriter.append("Id,Marque,modele,prix_achat,prix_vente,quantite,Date_sortie,status\n");

            // Write Data
            while (resultSet.next()) {
                fileWriter.append(String.valueOf(resultSet.getInt("Id"))).append(",");
                fileWriter.append(resultSet.getString("Marque")).append(",");
                fileWriter.append(resultSet.getString("modele")).append(",");
                fileWriter.append(String.valueOf(resultSet.getInt("prix_achat"))).append(",");
                fileWriter.append(String.valueOf(resultSet.getInt("prix_vente"))).append(",");
                fileWriter.append(String.valueOf(resultSet.getInt("quantite"))).append(",");
                fileWriter.append(String.valueOf(resultSet.getInt("Date_sortie"))).append(",");
                fileWriter.append(resultSet.getString("status")).append("\n");
            }
        } catch (IOException | SQLException e) {
            e.printStackTrace(); // Handle exceptions
        }
    }
   
    private void searchInDatabase() {
        List<liste_vehicule> searchResults = new ArrayList<>();



        // Construct your SQL query
        String sql = "SELECT * FROM stocks WHERE " +
                "Marque LIKE ? AND " +
                "modele LIKE ? AND " +
                "(prix_achat = ? OR ? = '') AND " +
                "(prix_vente = ? OR ? = '') AND " +
                "(quantite = ? OR ? = '') AND " +
                "(Id = ? OR ? = '') AND " +
                "status LIKE ?";


        try (Connection connection = MysqlConnection.getDBConnection();
             PreparedStatement ps = connection.prepareStatement(sql)) {

        	// Set parameters for the SQL query
        	ps.setString(1, "%" + rechercheMarque.getText() + "%");
        	ps.setString(2, "%" + rechercheModele.getText() + "%");
        	ps.setString(3, recherchePrixAchat.getText().isEmpty() ? "" : recherchePrixAchat.getText());
        	ps.setString(4, recherchePrixAchat.getText().isEmpty() ? "" : recherchePrixAchat.getText());
        	ps.setString(5, recherchePrixVente.getText().isEmpty() ? "" : recherchePrixVente.getText());
        	ps.setString(6, recherchePrixVente.getText().isEmpty() ? "" : recherchePrixVente.getText());
        	ps.setString(7, rechercheQuantite.getText().isEmpty() ? "" : rechercheQuantite.getText());
        	ps.setString(8, rechercheQuantite.getText().isEmpty() ? "" : rechercheQuantite.getText());
        	ps.setString(9, rechercheId.getText().isEmpty() ? "" : rechercheId.getText());
        	ps.setString(10, rechercheId.getText().isEmpty() ? "" : rechercheId.getText());
        	ps.setString(11, "%" + rechercheStatus.getText() + "%");


        	try (ResultSet results = ps.executeQuery()) {
        	    while (results.next()) {
        	        liste_vehicule vehicule = new liste_vehicule();

        	        vehicule.setId(results.getInt("Id"));
        	        vehicule.setMarque(results.getString("Marque"));
        	        vehicule.setModele(results.getString("modele"));
        	        vehicule.setPrix_achat(results.getDouble("prix_achat"));
        	        vehicule.setPrix_vente(results.getDouble("prix_vente"));
        	        vehicule.setQuantite(results.getInt("quantite"));
        	        vehicule.setDate_sortie(results.getString("Date_sortie"));
        	        vehicule.setStatus(results.getString("status"));
        	        
        	        // Assuming there's a method in liste_vehicule to set the image path
        	        vehicule.setImagePath(results.getString("vehicule_image_path"));

        	        searchResults.add(vehicule);
        	    }
        	}

        } catch (SQLException e) {
            e.printStackTrace();
        }

        updateVehiculeList(searchResults);
    }

    

}