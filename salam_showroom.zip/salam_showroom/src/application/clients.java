package application;

public class clients {
    private String lastName;
    private String firstName;
    private String CIN;
    private String address;
    private String phone;

    public clients(String lastName, String firstName, String CIN, String address, String phone) {
        this.lastName = lastName;
        this.firstName = firstName;
        this.CIN = CIN;
        this.address = address;
        this.phone = phone;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getCIN() {
        return CIN;
    }

    public void setCIN(String CIN) {
        this.CIN = CIN;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }
}
