package application;

import java.io.FileWriter;

import java.io.IOException;
import java.io.Serializable;
import java.net.URL;
import java.rmi.AccessException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.ResourceBundle;
import java.util.stream.Collectors;

import javax.swing.text.html.ImageView;
import javax.swing.tree.DefaultTreeCellEditor.DefaultTextField;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import model.liste_employes;
import model.liste_vehicule;

public class liste_employe_controller implements Initializable{

 
	    @FXML
	    private TextField rechercheEmployeById;
	    @FXML
	    private TextField rechercheEmployeByNom;
	    @FXML
	    private TextField rechercheEmployeByPrenom;
	    @FXML
	    private TextField rechercheEmployeByCin;
	    @FXML
	    private TextField rechercheEmployeByAddresse;
	    @FXML
	    private TextField rechercheEmployeByTelephone;
	    @FXML
	    private TextField rechercheEmployeBySalaire;
	    @FXML
	    private TextField rechercheEmployeByDepartement;
		  @FXML
		    private VBox listelayout1;	
	  @Override
	    public void initialize (URL location, ResourceBundle resources) {
	   	List <liste_employes> listesFromDatabase = new ArrayList<>(listesFromDatabase());
  	for (int i = 0 ; i<listesFromDatabase.size() ; i++) {
  		FXMLLoader fxmlloader = new FXMLLoader ();
  		fxmlloader.setLocation(getClass().getResource("ithem_employe.fxml"));
  		
  		try {
  			HBox hBox = fxmlloader.load();
  			ithem_employe_controller cic = fxmlloader.getController();
  			cic.setData(listesFromDatabase.get(i));
  			listelayout1.getChildren().add(hBox);
  		
  			
  		}catch (IOException e) {
  			e.printStackTrace();
  		}
  		
  	}
    rechercheEmployeById.textProperty().addListener((observable, oldValue, newValue) -> searchInDatabase());
    rechercheEmployeByNom.textProperty().addListener((observable, oldValue, newValue) -> searchInDatabase());
    rechercheEmployeByPrenom.textProperty().addListener((observable, oldValue, newValue) -> searchInDatabase());
    rechercheEmployeByCin.textProperty().addListener((observable, oldValue, newValue) -> searchInDatabase());
    rechercheEmployeByAddresse.textProperty().addListener((observable, oldValue, newValue) -> searchInDatabase());
    rechercheEmployeByTelephone.textProperty().addListener((observable, oldValue, newValue) -> searchInDatabase());
    rechercheEmployeBySalaire.textProperty().addListener((observable, oldValue, newValue) -> searchInDatabase());
    rechercheEmployeByDepartement.textProperty().addListener((observable, oldValue, newValue) -> searchInDatabase());
}
	  private void searchInDatabase() {
		    List<liste_employes> searchResults = new ArrayList<>();

		    // Fetch the text from each TextField
		    String id = rechercheEmployeById.getText();
		    String nom = rechercheEmployeByNom.getText();
		    String prenom = rechercheEmployeByPrenom.getText();
		    String cin = rechercheEmployeByCin.getText();
		    String adresse = rechercheEmployeByAddresse.getText();
		    String telephone = rechercheEmployeByTelephone.getText();
		    String salaire = rechercheEmployeBySalaire.getText();
		    String departement = rechercheEmployeByDepartement.getText();

		    StringBuilder sqlBuilder = new StringBuilder("SELECT * FROM employes WHERE ");
		    List<String> conditions = new ArrayList<>();
		    List<Object> parameters = new ArrayList<>();

		    if (!id.isEmpty()) {
		        conditions.add("id = ?");
		        parameters.add(Integer.parseInt(id));
		    }
		    if (!nom.isEmpty()) {
		        conditions.add("nom LIKE ?");
		        parameters.add("%" + nom + "%");
		    }
		    // ... [similar for other fields]
		    if (!prenom.isEmpty()) {
		        conditions.add("prenom LIKE ?");
		        parameters.add("%" + prenom + "%");
		    }
		    if (!cin.isEmpty()) {
		        conditions.add("cin LIKE ?");
		        parameters.add("%" + cin + "%");
		    }
		    if (!adresse.isEmpty()) {
		        conditions.add("adresse LIKE ?");
		        parameters.add("%" + adresse + "%");
		    }
		    if (!telephone.isEmpty()) {
		        conditions.add("numero_telephone LIKE ?");
		        parameters.add("%" + telephone + "%");
		    }
		    if (!salaire.isEmpty()) {
		        conditions.add("salaire = ?");
		        parameters.add(Double.parseDouble(salaire));
		    }
		    if (!departement.isEmpty()) {
		        conditions.add("departement LIKE ?");
		        parameters.add("%" + departement + "%");
		    }

		    if (!conditions.isEmpty()) {
		        sqlBuilder.append(String.join(" AND ", conditions));
		    } else {
		        sqlBuilder.append("1 = 1"); // Select all if no conditions
		    }

		    try (Connection connection = MysqlConnection.getDBConnection();
		         PreparedStatement ps = connection.prepareStatement(sqlBuilder.toString())) {

		        for (int i = 0; i < parameters.size(); i++) {
		            if (parameters.get(i) instanceof String) {
		                ps.setString(i + 1, (String) parameters.get(i));
		            } else if (parameters.get(i) instanceof Integer) {
		                ps.setInt(i + 1, (Integer) parameters.get(i));
		            } else if (parameters.get(i) instanceof Double) {
		                ps.setDouble(i + 1, (Double) parameters.get(i));
		            }
		            // Add other data types if necessary
		        }

		        try (ResultSet results = ps.executeQuery()) {
		            while (results.next()) {
		                liste_employes result = new liste_employes();
		                result.setId(results.getInt("id"));
		                result.setNom(results.getString("nom"));
		                result.setPrenom(results.getString("prenom"));
		                // ... (set other attributes)
		                result.setCin(results.getString("cin"));
		                result.setAdresse(results.getString("adresse"));
		                result.setTelephone(results.getString("numero_telephone"));
		                result.setSalaire(results.getDouble("salaire"));
		                result.setDepartement(results.getString("departement"));
		                // Add any other missing attributes here

		                searchResults.add(result);
		            }
		        }
		    } catch (SQLException e) {
		        e.printStackTrace();
		    }

		    updateDisplayedList(searchResults);
		}


	    private void updateDisplayedList(List<liste_employes> searchResults) {
	        listelayout1.getChildren().clear(); // Clear existing items
	        for (liste_employes listItem : searchResults) {
	            FXMLLoader fxmlloader = new FXMLLoader();
	            fxmlloader.setLocation(getClass().getResource("ithem_employe.fxml"));

	            try {
	                HBox hBox = fxmlloader.load();
	                ithem_employe_controller cic = fxmlloader.getController();
	                cic.setData(listItem);
	                listelayout1.getChildren().add(hBox);
	            } catch (IOException e) {
	                e.printStackTrace();
	            }
	        }
	    }
 

	  private List<liste_employes> listesFromDatabase() {
		    List<liste_employes> ls = new ArrayList<>();

		    try {
		        Connection connection = MysqlConnection.getDBConnection();
		        String sql = "SELECT * FROM employes";
		        try (PreparedStatement ps = connection.prepareStatement(sql);
		             ResultSet results = ps.executeQuery()) {
		        	    while (results.next()) {
		                int id = results.getInt("id");
		                String nom = results.getString("nom");
		                String prenom = results.getString("prenom");
		                String cin = results.getString("cin");
		                String adresse = results.getString("adresse");
		                String telephone = results.getString("numero_telephone");
		                String departement = results.getString("departement");
		                double salaire = results.getDouble("salaire");



		                liste_employes list = new liste_employes();
		                list.setId(id);
		                list.setNom(nom);
		                list.setPrenom(prenom);
		                list.setCin(cin);
		                list.setAdresse(adresse);
		                list.setTelephone(telephone);
		                list.setDepartement(departement);
		                list.setSalaire(salaire);

		                ls.add(list);
		            }
		        }
		    } catch (SQLException e) {
		        e.printStackTrace(); // Handle exceptions appropriately, you may log or throw a custom exception
		    }

		    return ls;
		    
		}
	  
	  
	  
	  
	  
	  @FXML
	  private void refreshData(ActionEvent event) {
		  loadEmploye(); // Assurez-vous que cette méthode existe dans votre contrôleur
	  }
	  
	  private void loadEmploye() {
	        List<liste_employes> allVehicule = listesFromDatabase();
	        updateEmployeListe(allVehicule);
	    }
	    
	   
	    private void updateEmployeListe(List<liste_employes> employes) {
	    	listelayout1.getChildren().clear(); // Supprime tous les éléments actuels de la liste

	        for (liste_employes empe : employes) {
	            FXMLLoader fxmlloader = new FXMLLoader();
	            fxmlloader.setLocation(getClass().getResource("ithem_employe.fxml"));

	            try {
	                HBox hBox = fxmlloader.load();
	                ithem_employe_controller cics = fxmlloader.getController();
	                cics.setData(empe);
	                listelayout1.getChildren().add(hBox);
	            } catch (IOException e) {
	                e.printStackTrace();
	            }
	        }
	       
	    }
	  
		 private Stage stage;
		 private Scene scene;
		 private Parent root;
	    
		    @FXML
		    void SwitchToAddEmploye(ActionEvent event) throws IOException {
		  	  root = FXMLLoader.load(getClass().getResource("nouv_emplo.fxml"));
		  	  stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		  	  scene = new Scene(root);
		  	  stage.setScene(scene);
		  	  stage.show();
		    }
	    @FXML
	    void SwitchToAddProduit(ActionEvent event) throws IOException {
	  	  root = FXMLLoader.load(getClass().getResource("nouv_vehicule.fxml"));
	  	  stage = (Stage)((Node)event.getSource()).getScene().getWindow();
	  	  scene = new Scene(root);
	  	  stage.setScene(scene);
	  	  stage.show();
	    }
	    @FXML
	    void SwitchToStock(ActionEvent event) throws IOException {
	    	  root = FXMLLoader.load(getClass().getResource("liste_de_stock.fxml"));
	      	  stage = (Stage)((Node)event.getSource()).getScene().getWindow();
	      	  scene = new Scene(root);
	      	  stage.setScene(scene);
	      	  stage.show();
	    }

	    @FXML
	    void SwitchToAddVehicule(ActionEvent event) throws IOException {
	    	  root = FXMLLoader.load(getClass().getResource("nouv_vehicule.fxml"));
	      	  stage = (Stage)((Node)event.getSource()).getScene().getWindow();
	      	  scene = new Scene(root);
	      	  stage.setScene(scene);
	      	  stage.show();
	    }

	    @FXML
	    void SwitchToClients(ActionEvent event) throws IOException {
	    	  root = FXMLLoader.load(getClass().getResource("liste_des_clients.fxml"));
	      	  stage = (Stage)((Node)event.getSource()).getScene().getWindow();
	      	  scene = new Scene(root);
	      	  stage.setScene(scene);
	      	  stage.show();
	    }

	    @FXML
	    void SwitchToDashboard(ActionEvent event) throws IOException {
	    	  root = FXMLLoader.load(getClass().getResource("dashboardVoiture.fxml"));
	      	  stage = (Stage)((Node)event.getSource()).getScene().getWindow();
	      	  scene = new Scene(root);
	      	  stage.setScene(scene);
	      	  stage.show();
	    }

	    @FXML
	    void SwitchToEmploye(ActionEvent event) throws IOException {
	    	  root = FXMLLoader.load(getClass().getResource("liste_des_employe.fxml"));
	      	  stage = (Stage)((Node)event.getSource()).getScene().getWindow();
	      	  scene = new Scene(root);
	      	  stage.setScene(scene);
	      	  stage.show();
	    }

	    @FXML
	    void SwitchToTransactions(ActionEvent event) throws IOException {
	    	  root = FXMLLoader.load(getClass().getResource("liste_des_transactions.fxml"));
	      	  stage = (Stage)((Node)event.getSource()).getScene().getWindow();
	      	  scene = new Scene(root);
	      	  stage.setScene(scene);
	      	  stage.show();
	    }
	    @FXML
	    private void exportEmployesToCSV() {
	        String csvFilePath = "employes.csv";

	        try (FileWriter fileWriter = new FileWriter(csvFilePath)) {
	            Connection connection = MysqlConnection.getDBConnection();
	            String sql = "SELECT * FROM employes";
	            Statement statement = connection.createStatement();
	            ResultSet resultSet = statement.executeQuery(sql);

	            // Write Column Headers
	            fileWriter.append("id,nom,prenom,cin,adresse,numero_telephone,departement,salaire\n");

	            // Write Data
	            while (resultSet.next()) {
	                fileWriter.append(String.valueOf(resultSet.getInt("id"))).append(",");
	                fileWriter.append(resultSet.getString("nom")).append(",");
	                fileWriter.append(resultSet.getString("prenom")).append(",");
	                fileWriter.append(resultSet.getString("cin")).append(",");
	                fileWriter.append(resultSet.getString("adresse")).append(",");
	                fileWriter.append(resultSet.getString("numero_telephone")).append(",");
	                fileWriter.append(resultSet.getString("departement")).append(",");
	                fileWriter.append(String.valueOf(resultSet.getBigDecimal("salaire"))).append("\n");
	            }
	        } catch (IOException | SQLException e) {
	            e.printStackTrace(); // Handle exceptions
	        }
	    }

	


	  
}