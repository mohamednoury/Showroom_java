package application;

import java.util.Date;

public class transaction {
    private int id_vehicule;
    private int id_client;
    private Date date;
    private float montant;

    public transaction(int id_vehicule, int id_client, Date date, float montant){
        this.id_vehicule = id_vehicule;
        this.id_client = id_client;
        this.date = date;
        this.montant = montant;
    }

    public int getIdVehicule() {
        return id_vehicule;
    }

    public void setIdVehicule(int id_vehicule) {
        this.id_vehicule = id_vehicule;
    }

    public int getIdClient() {
        return id_client;
    }

    public void setIdClient(int id_client) {
        this.id_client = id_client;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public float getMontant() {
        return montant;
    }

    public void setMontant(float montant) {
        this.montant = montant;
    }
}
