package application;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import model.liste;
import model.liste_clients;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Delete_client_controller {

	@FXML
    private Label id;

    @FXML
    private Button enregistrer;

    @FXML
    private TextField nom;

    @FXML
    private TextField prenom;

    @FXML
    private TextField cin;

    @FXML
    private TextField addresse;

    @FXML
    private TextField telephone;

    private liste_clients data;
    
    private liste_clients originalData;
	
   
    @FXML
    private Button delete;

    public void setData(liste_clients data) {
        this.data = data;
        // Set the values to your UI elements if needed
    }
    
    @FXML
    void DeleteClient(ActionEvent event) {
        int Id = this.data.getId();

    	 try {
    	        

        // Get a connection to the database
        Connection connection = MysqlConnection.getDBConnection(); // Replace YourDatabaseUtil with your database connection utility
        
        try {
            // Prepare the DELETE SQL query
            String deleteQuery = "DELETE FROM clients WHERE id = ?"; // Replace your_table_name with your actual table name
            PreparedStatement preparedStatement = connection.prepareStatement(deleteQuery);
            preparedStatement.setInt(1, data.getId()); // Assuming getId_transaction() gets the ID of the transaction

            // Execute the query to delete the record
            int rowsDeleted = preparedStatement.executeUpdate();

            if (rowsDeleted > 0) {
                System.out.println("Record deleted successfully!");
            } else {
                System.out.println("Record not found or unable to delete.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            // Close the database connection
        	MysqlConnection.closeConnection(connection); // Replace YourDatabaseUtil with your database connection utility
        }
    	 } catch (SQLException e) {
 	        // Handle the SQLException
 	        e.printStackTrace(); // You can log the exception or show an error message
 	    }

        // Close the stage
        Stage stage = (Stage) delete.getScene().getWindow();
        stage.close();
    }
    
    
    @FXML
    private Button annuler;

 
@FXML
void SwitchToliste(ActionEvent event) throws IOException {
   // Get the current stage
   Stage stage = (Stage) annuler.getScene().getWindow();
   stage.close();
}  
   
	   

    
    
}
