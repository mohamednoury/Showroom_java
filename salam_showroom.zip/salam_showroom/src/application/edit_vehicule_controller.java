package application;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import model.liste_vehicule;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class edit_vehicule_controller {

	@FXML
    private Label ID;
	
	  @FXML
	    private Button enregistrer;

    @FXML
    private TextField quantiteVehicul;

    @FXML
    private  TextField statusVehicul;

    @FXML
    private Button cancel_information;

    @FXML
    private AnchorPane photoVehicule;

    @FXML
    private TextField marqu;

    @FXML
    private TextField model;

    @FXML
    private TextField prixAchatVehicul;

    @FXML
    private TextField prixVenteVehicul;

    @FXML
    private TextField annesorti;
	
    private liste_vehicule originalData;
    private Connection connection;
    

    @FXML
    private ImageView img;
    
	
	    
	    
	public void initializeData(liste_vehicule list) {
	    this.originalData = list;
	    ID.setText(String.valueOf(list.getId()));
	    quantiteVehicul.setText(String.valueOf(list.getQuantite()));
	    model.setText(list.getModele());
	    marqu.setText(list.getMarque());
	    prixAchatVehicul.setText(String.valueOf(list.getPrix_achat()));
	    prixVenteVehicul.setText(String.valueOf(list.getPrix_vente()));
	    annesorti.setText(list.getDate_sortie());
	    statusVehicul.setText(list.getStatus());
	    
	    if (list.getImagePath() != null && !list.getImagePath().isEmpty()) {
            try {
                Image image = new Image(new FileInputStream(list.getImagePath()));
                img.setImage(image);
            } catch (FileNotFoundException e) {
                System.err.println("Error loading image: " + list.getImagePath());
                e.printStackTrace();
            }
        }
	    
	}
	



    

   
    
    
    @FXML
    void UpdateStock() {
        try {
            originalData.setId(Integer.parseInt(ID.getText()));
            originalData.setQuantite(Integer.parseInt(quantiteVehicul.getText()));
            originalData.setModele(model.getText());
            originalData.setMarque(marqu.getText());
            originalData.setPrix_achat(Double.parseDouble(prixAchatVehicul.getText()));
            originalData.setPrix_vente(Double.parseDouble(prixVenteVehicul.getText()));
            originalData.setDate_sortie(annesorti.getText());
            originalData.setStatus(statusVehicul.getText());
        } catch (NumberFormatException e) {
            e.printStackTrace(); // Handle parsing errors
        }

        updateDatabase(originalData);

        // Close the edit view
        Stage stage = (Stage) enregistrer.getScene().getWindow();
        stage.close();
    }

    private void updateDatabase(liste_vehicule updatedData) {
        try {
            connection = MysqlConnection.getDBConnection();
            connection.setAutoCommit(false);

            String sql = "UPDATE stocks SET Marque=?, modele=?, prix_achat=?, prix_vente=?, quantite=?, Date_sortie=? , status= ? WHERE Id=?";
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setString(1, updatedData.getMarque());
                statement.setString(2, updatedData.getModele());
                statement.setDouble(3, updatedData.getPrix_achat());
                statement.setDouble(4, updatedData.getPrix_vente());
                statement.setInt(5, updatedData.getQuantite());
                statement.setString(6, updatedData.getDate_sortie());
                statement.setString(7, updatedData.getStatus());
                statement.setInt(8, updatedData.getId());

                statement.executeUpdate();
            }

            connection.commit();
        } catch (SQLException e) {
            e.printStackTrace();
            try {
                if (connection != null) {
                    connection.rollback();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        } finally {
            try {
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }
    
    private Stage stage;
	 private Scene scene;
	 private Parent root;
   
	 
	@FXML
	    private Button annuler;
	
	 
   @FXML
   void SwitchToliste(ActionEvent event) throws IOException {
	   Stage stage = (Stage) annuler.getScene().getWindow();
       stage.close();
   }
}
