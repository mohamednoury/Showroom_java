package application;

	import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ResourceBundle;
import javax.swing.text.html.ImageView;

import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Modality;
import javafx.stage.Stage;
import model.liste;
import model.liste_clients;

	public class ithem_client_controller implements Initializable {

		  @FXML
		    private Label id;

		    @FXML
		    private Label nom;

		    @FXML
		    private Label prenom;

		    @FXML
		    private Label cin;

		    @FXML
		    private Label addresse;

		    @FXML
		    private Label telephone;
		    
		    private liste_clients data; 

		   
		    public void setData(liste_clients list) {
		    	this.data = list;
		        id.setText(String.valueOf(list.getId()));
		    	nom.setText(list.getNom());
		    	prenom.setText(list.getPrenom());
		    	addresse.setText(list.getAdresse());
		    	cin.setText(list.getCin());
		    	telephone.setText(list.getTelephone());

		    }
		    
		    @FXML
		    private Button view_client;

		    private Stage stage;
		    private Scene scene;
		    private Parent root;

		    
		    
		    @FXML
		    void SwitchToViewClient(ActionEvent event) throws IOException {
		        FXMLLoader loader = new FXMLLoader(getClass().getResource("view_client.fxml"));
		        Parent root = loader.load();

		        view_client_controller viewController = loader.getController();
		        viewController.setData(data); // Pass the selected transaction data

		        Stage stage = new Stage();
		        Scene scene = new Scene(root);
		        stage.setScene(scene);
		        stage.initModality(Modality.APPLICATION_MODAL); // Set modality before showing the stage
		        stage.setX(450);
		        stage.setY(250);
		        stage.showAndWait();
		    }
		    
		    
		    
		    @FXML
		    private Button edit_client;

		    @FXML
		    void SwitchToEditClient(ActionEvent event) throws IOException {
		        FXMLLoader loader = new FXMLLoader(getClass().getResource("edit_client.fxml"));
		        Parent root = loader.load();

		        edit_client_controller editController = loader.getController();
		        editController.initializeData(data); // Pass the selected transaction data

		        Stage stage = new Stage();
		        Scene scene = new Scene(root);
		        stage.setScene(scene);
		        stage.initModality(Modality.APPLICATION_MODAL); // Set modality before showing the stage
		        stage.setX(450);
		        stage.setY(250);
		        stage.showAndWait();
		    }
		    
		    @FXML
		    private Button Delete_client;
		   
		    @FXML
		    void SwitchToDeleteClient(ActionEvent event) throws IOException {
		        FXMLLoader loader = new FXMLLoader(getClass().getResource("Delete_client.fxml"));
		        Parent root = loader.load();

		        Delete_client_controller deleteController = loader.getController();
		        deleteController.setData(data); // Pass the selected transaction data

		        Stage stage = new Stage();
		        Scene scene = new Scene(root);
		        stage.setScene(scene);
		        stage.setX(530);
		        stage.setY(350);
		        stage.initModality(Modality.APPLICATION_MODAL);
		        stage.showAndWait();
		    }
		    
		    
		    
		    @Override 
		    public void initialize (URL location, ResourceBundle resources) {
		    	
		    }
		   
	}

	