package application;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.nio.file.Files;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

public class addNewVehicleController implements Initializable{
	private File selectedImageFile;


    @FXML
    private Button ajouterInformation;

    @FXML
    private Button cancel_information;

    @FXML
    private AnchorPane photoVehicule;

    @FXML
    private TextField prixAchatVehicul;

    @FXML
    private TextField prixVenteVehicul;

    @FXML
    private TextField quantiteVehicul;
    
    @FXML
    private ChoiceBox<Integer> annesorti;
    
    @FXML
    private ChoiceBox<String> marqu;

    @FXML
    private ChoiceBox<String> model;

    @FXML
    private ChoiceBox<String> statusVehicul;
	
	private Integer[] annee = {2010,2011,2012,2013,2014,2015,2016,2017,2018,2019,2020,2021,2022,2023,2024};
	private String[] marq = {"Mercedes-Benz","Dacia","Volkswagen","Bmw","Honda","Toyota","Ford","Audi","Nissan","Tesla","Cheverolet"};
	private String[] mod = {"Brabus","Corolla","Camry","C220d","Rs6","A4","Focus","Qashqai","Golf"};
	private String[] status = {"Disponible","Indisponible","Critique"};

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		annesorti.getItems().addAll(annee);	
		marqu.getItems().addAll(marq);
		model.getItems().addAll(mod);	
		statusVehicul.getItems().addAll(status);
	}
	 @FXML
	    void ajouterInformation_method(ActionEvent event) {
	        String marque = marqu.getValue();
	        String modele = model.getValue();
	        int prixAchatVehicule = Integer.parseInt(prixAchatVehicul.getText());
	        int prixVenteVehicule = Integer.parseInt(prixVenteVehicul.getText());
	        int anneeDeSortie = annesorti.getValue();
	        int quantiteVehicule = Integer.parseInt(quantiteVehicul.getText());
	        String statusVehicule = statusVehicul.getValue();

	        vehicle vehicule = new vehicle(marque, modele, prixAchatVehicule, prixVenteVehicule, anneeDeSortie, quantiteVehicule, statusVehicule);
	        insertVehicule(vehicule);

	     // Clear input fields
	        marqu.getSelectionModel().clearSelection();
	        model.getSelectionModel().clearSelection();
	        prixAchatVehicul.clear();
	        prixVenteVehicul.clear();
	        annesorti.getSelectionModel().clearSelection();
	        quantiteVehicul.clear();
	        statusVehicul.getSelectionModel().clearSelection();

	    }

	 private void insertVehicule(vehicle vehicule) {
		    Connection connection = null;
		    PreparedStatement statement = null;

		    try {
		        connection = MysqlConnection.getDBConnection();
		        String sql = "INSERT INTO `stocks` (`Date_sortie`, `Marque`, `modele`, `prix_achat`, `prix_vente`, `quantite`, `status`, `vehicule_image_path`) VALUES (?, ?, ?, ?, ?, ?, ?, ?);";

		        statement = connection.prepareStatement(sql);
		        statement.setInt(1, vehicule.getanneeDeSortie());
		        statement.setString(2, vehicule.getmarque());
		        statement.setString(3, vehicule.getmodele());
		        statement.setInt(4, vehicule.getprixAchatVehicule());
		        statement.setInt(5, vehicule.getprixVenteVehicule());
		        statement.setInt(6, vehicule.getquantiteVehicule());
		        statement.setString(7, vehicule.getstatusVehicule());

		        // Store the image file path
		        if (selectedImageFile != null) {
		            String imagePath = selectedImageFile.getAbsolutePath();
		            statement.setString(8, imagePath);
		        } else {
		            statement.setNull(8, Types.VARCHAR);
		        }

		        statement.executeUpdate();

		    } catch (SQLException e) {
		        e.printStackTrace();
		    } finally {
		        try {
		            if (statement != null) statement.close();
		            if (connection != null) connection.close();
		        } catch (SQLException ex) {
		            ex.printStackTrace();
		        }
		    }
		}


	    @FXML
	    void cancel_information_method(ActionEvent event) {
	        // Clear input fields when the cancel button is clicked
	    	marqu.getSelectionModel().clearSelection();
	        model.getSelectionModel().clearSelection();
	        prixAchatVehicul.clear();
	        prixVenteVehicul.clear();
	        annesorti.getSelectionModel().clearSelection();
	        quantiteVehicul.clear();
	        statusVehicul.getSelectionModel().clearSelection();
	    }
		 private Stage stage;
		 private Scene scene;
		 private Parent root;
	    @FXML
	    void SwitchToClients(ActionEvent event) throws IOException {
	    	  root = FXMLLoader.load(getClass().getResource("liste_des_clients.fxml"));
	      	  stage = (Stage)((Node)event.getSource()).getScene().getWindow();
	      	  scene = new Scene(root);
	      	  stage.setScene(scene);
	      	  stage.show();
	    }

	    @FXML
	    void SwitchToDashboard(ActionEvent event) throws IOException {
	    	  root = FXMLLoader.load(getClass().getResource("dashboardVoiture.fxml"));
	      	  stage = (Stage)((Node)event.getSource()).getScene().getWindow();
	      	  scene = new Scene(root);
	      	  stage.setScene(scene);
	      	  stage.show();
	    }

	    @FXML
	    void SwitchToEmploye(ActionEvent event) throws IOException {
	    	  root = FXMLLoader.load(getClass().getResource("liste_des_employes.fxml"));
	      	  stage = (Stage)((Node)event.getSource()).getScene().getWindow();
	      	  scene = new Scene(root);
	      	  stage.setScene(scene);
	      	  stage.show();
	    }

	    @FXML
	    void SwitchToTransactions(ActionEvent event) throws IOException {
	    	  root = FXMLLoader.load(getClass().getResource("liste_des_transactions.fxml"));
	      	  stage = (Stage)((Node)event.getSource()).getScene().getWindow();
	      	  scene = new Scene(root);
	      	  stage.setScene(scene);
	      	  stage.show();
	    }
	    @FXML
	    void SwitchToStocks(ActionEvent event) throws IOException {
	    	  root = FXMLLoader.load(getClass().getResource("liste_de_stock.fxml"));
	      	  stage = (Stage)((Node)event.getSource()).getScene().getWindow();
	      	  scene = new Scene(root);
	      	  stage.setScene(scene);
	      	  stage.show();
	    }
	    @FXML
	    void addNewPhoto(MouseEvent event) {
	        FileChooser fileChooser = new FileChooser();
	        // Set extension filters, for example, for image files
	        FileChooser.ExtensionFilter imageFilter = new FileChooser.ExtensionFilter("Image Files", "*.jpg", "*.png");
	        fileChooser.getExtensionFilters().add(imageFilter);

	        // Open file chooser and get the selected file
	        File file = fileChooser.showOpenDialog(photoVehicule.getScene().getWindow());

	        if (file != null) {
	            // Set the selected image file
	            selectedImageFile = file;

	            Image image = new Image(file.toURI().toString());
	            ImageView imageView = new ImageView(image);
	            imageView.setFitWidth(362);
	            imageView.setFitHeight(267);
	            imageView.setPreserveRatio(true);
	            photoVehicule.getChildren().clear();
	            photoVehicule.getChildren().add(imageView);
	        }
	    }


}
