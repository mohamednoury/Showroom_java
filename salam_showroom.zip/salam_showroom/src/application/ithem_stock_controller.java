package application;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Modality;
import javafx.stage.Stage;
import model.liste_vehicule;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class ithem_stock_controller implements Initializable {

    @FXML
    private ImageView img;

    @FXML
    private Label marque;

    @FXML
    private Label modele;

    @FXML
    private Label prix_achat;

    @FXML
    private Label prix_vente;

    @FXML
    private Label quantite;

    @FXML
    private Label id;

    @FXML
    private Label date_sortie;

    @FXML
    private Label status;

    private liste_vehicule data;

    @FXML
    private Button delete;

    public void setData(liste_vehicule list) {
        id.setText(String.valueOf(list.getId()));
        marque.setText(list.getMarque());
        modele.setText(list.getModele());
        prix_achat.setText(String.valueOf(list.getPrix_achat()));
        prix_vente.setText(String.valueOf(list.getPrix_vente()));
        quantite.setText(String.valueOf(list.getQuantite()));
        date_sortie.setText(list.getDate_sortie());
        status.setText(list.getStatus());

        if (list.getImagePath() != null && !list.getImagePath().isEmpty()) {
            try {
                Image image = new Image(new FileInputStream(list.getImagePath()));
                img.setImage(image);
            } catch (FileNotFoundException e) {
                System.err.println("Error loading image: " + list.getImagePath());
                e.printStackTrace();
            }
        }

        this.data = list; // Set the data for later use in DeleteVehicule
    }
    
    
    @FXML
    private Button view_vehicule;
    

    @FXML
    void SwitchToViewVehicule(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("view_vehicule.fxml"));
        Parent root = loader.load();

        view_vehicule_controller viewController = loader.getController();
        viewController.setData(data); // Pass the selected transaction data

        // Cr�er une nouvelle sc�ne
        Scene scene = new Scene(root);

        // Cr�er une nouvelle fen�tre modale
        Stage newStage = new Stage();
        newStage.setScene(scene);
        newStage.setX(300);
        newStage.setY(155);
        newStage.initModality(Modality.APPLICATION_MODAL);
        newStage.showAndWait(); // Bloque l'ex�cution jusqu'� ce que la fen�tre soit ferm�e

        // Le code ici sera ex�cut� apr�s la fermeture de la fen�tre view_vehicule

        // Vous pouvez �galement actualiser les donn�es de la fen�tre actuelle ici, si n�cessaire
    }

    
   

    @FXML
    void SwitchToDeleteVehicule(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("Delete_vehicule.fxml"));
        Parent root = loader.load();

        Delete_vehicule_controller deleteController = loader.getController();
        deleteController.setData(data); // Pass the selected transaction data

      
        
        Stage stage = new Stage();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.setX(530);
        stage.setY(350);
        stage.initModality(Modality.APPLICATION_MODAL);
        stage.showAndWait();
        
    }
    
    
    @FXML
    private Button edit_vehicule;

    @FXML
    void SwitchToEditVehicule(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("edit_vehicule.fxml"));
        Parent root = loader.load();

        edit_vehicule_controller editController = loader.getController();
        editController.initializeData(data); // Pass the selected transaction data

        Stage stage = new Stage();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.setX(300);
        stage.setY(155);
        stage.initModality(Modality.APPLICATION_MODAL);
        stage.showAndWait();
    }
    

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        // Initialization code if needed
    }
}
