package application;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class MysqlConnection {
	
	private static final String DB_NAME = "showroom";
	private static final String DB_IP = "127.0.0.1";
	private static final String DB_USER = "root";
	private static final String DB_PASSWORD = "";
	
	public static Connection getDBConnection() throws SQLException {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			return DriverManager.getConnection("jdbc:mysql://" + DB_IP + "/" + DB_NAME, DB_USER, DB_PASSWORD);
		} catch (ClassNotFoundException | SQLException e) {
			throw new SQLException("Error establishing a database connection: " + e.getMessage(), e);
		}
	}

	public static void closeConnection(Connection connection) {
		if (connection != null) {
			try {
				connection.close();
			} catch (SQLException e) {
				System.err.println("Error closing the database connection: " + e.getMessage());
			}
		}
	}
}
