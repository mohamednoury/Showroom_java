package application;

import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.stage.Stage;
import model.liste;

public class view_transaction_controller {

	  @FXML
	    private Label id;

	    @FXML
	    private Label id_vehicule;

	    @FXML
	    private Label id_client;

	    @FXML
	    private Label mantant;

	    @FXML
	    private Label date;
	    
	    
    public void setData(liste list) {
    	id.setText(String.valueOf(list.getId_transaction()));
        id_vehicule.setText(String.valueOf(list.getId_vehicule()));
        id_client.setText(String.valueOf(list.getId_client()));
        date.setText(list.getDate().toString());
        mantant.setText(String.valueOf(list.getMantant()));
    }
  
    @FXML
    private Button annuler;
    
    private Stage stage;
	 private Scene scene;
	 private Parent root;
 
@FXML
void SwitchToliste(ActionEvent event) throws IOException {
	 Stage stage = (Stage) annuler.getScene().getWindow();
     stage.close();
}
}
