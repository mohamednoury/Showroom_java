package application;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TextField;
import javafx.stage.Stage;



public class addNewEmployeeController implements Initializable{

	@FXML
    private Button ajouter_information;

    @FXML
    private Button cancel_information;

    @FXML
    private TextField employeeAddress;

    @FXML
    private TextField employeeCIN;

    @FXML
    private ChoiceBox<String> employeeDepartment;

    @FXML
    private TextField employeeFirstName;

    @FXML
    private TextField employeeLastName;

    @FXML
    private TextField employeePhone;

    @FXML
    private TextField employeeSalary;
    
    private String[] department = {"xdepartement","xdepartement","xdepartement","xdepartement","xdepartement","xdepartement"};

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		employeeDepartment.getItems().addAll(department);;
	}

    @FXML
    void ajouter_information_method(ActionEvent event) {
        String lastName = employeeLastName.getText();
        String firstName = employeeFirstName.getText();
        String cin = employeeCIN.getText();
        String address = employeeAddress.getText();
        String phone = employeePhone.getText();
        String department = employeeDepartment.getValue();
        float salary = Float.parseFloat(employeeSalary.getText());

        employee emply = new employee(lastName, firstName, cin, address, phone, department, salary);
        insertClient(emply);

        // Clear input fields
        employeeLastName.setText("");
        employeeFirstName.setText("");
        employeeCIN.setText("");
        employeeAddress.setText("");
        employeePhone.setText("");
        employeeDepartment.getSelectionModel().clearSelection();
        employeeSalary.setText("");
    }

    private void insertClient(employee emply) {
        try {
            // Assuming you have a method to get the database connection
            Connection connection = MysqlConnection.getDBConnection();

            // SQL query to insert a new client into the database
            String sql = "INSERT INTO `employes` (`adresse`, `cin`, `departement`, `nom`, `numero_telephone`, `prenom`, `salaire`) VALUES (?, ?, ?, ?, ?, ?, ?);";

            PreparedStatement statement = connection.prepareStatement(sql);

            statement.setString(1, emply.getAddress());
            statement.setString(2, emply.getCIN());
            statement.setString(3, emply.getDepartment());
            statement.setString(4, emply.getLastName());
            statement.setString(5, emply.getPhone());
            statement.setString(6, emply.getFirstName());
            statement.setFloat(7, emply.getSalary());
            

            statement.executeUpdate();
            
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    @FXML
    void cancel_information_method(ActionEvent event) {
    	// Clear input fields
        employeeLastName.setText("");
        employeeFirstName.setText("");
        employeeCIN.setText("");
        employeeAddress.setText("");
        employeePhone.setText("");
        employeeDepartment.getSelectionModel().clearSelection();
        employeeSalary.setText("");
    }
	 private Stage stage;
	 private Scene scene;
	 private Parent root;
   
   
   @FXML
   void SwitchToAddProduit(ActionEvent event) throws IOException {
 	  root = FXMLLoader.load(getClass().getResource("nouv_vehicule.fxml"));
 	  stage = (Stage)((Node)event.getSource()).getScene().getWindow();
 	  scene = new Scene(root);
 	  stage.setScene(scene);
 	  stage.show();
   }

   @FXML
   void SwitchToAddVehicule(ActionEvent event) throws IOException {
   	  root = FXMLLoader.load(getClass().getResource("nouv_vehicule.fxml"));
     	  stage = (Stage)((Node)event.getSource()).getScene().getWindow();
     	  scene = new Scene(root);
     	  stage.setScene(scene);
     	  stage.show();
   }

   @FXML
   void SwitchToClients(ActionEvent event) throws IOException {
   	  root = FXMLLoader.load(getClass().getResource("liste_des_clients.fxml"));
     	  stage = (Stage)((Node)event.getSource()).getScene().getWindow();
     	  scene = new Scene(root);
     	  stage.setScene(scene);
     	  stage.show();
   }

   @FXML
   void SwitchToDashboard(ActionEvent event) throws IOException {
   	  root = FXMLLoader.load(getClass().getResource("dashboardVoiture.fxml"));
     	  stage = (Stage)((Node)event.getSource()).getScene().getWindow();
     	  scene = new Scene(root);
     	  stage.setScene(scene);
     	  stage.show();
   }

   @FXML
   void SwitchToEmploye(ActionEvent event) throws IOException {
   	  root = FXMLLoader.load(getClass().getResource("liste_des_employes.fxml"));
     	  stage = (Stage)((Node)event.getSource()).getScene().getWindow();
     	  scene = new Scene(root);
     	  stage.setScene(scene);
     	  stage.show();
   }
   @FXML
   void SwitchToStocks(ActionEvent event) throws IOException {
   	  root = FXMLLoader.load(getClass().getResource("liste_de_stock.fxml"));
     	  stage = (Stage)((Node)event.getSource()).getScene().getWindow();
     	  scene = new Scene(root);
     	  stage.setScene(scene);
     	  stage.show();
   }

   @FXML
   void SwitchToTransactions(ActionEvent event) throws IOException {
   	  root = FXMLLoader.load(getClass().getResource("liste_des_transactions.fxml"));
     	  stage = (Stage)((Node)event.getSource()).getScene().getWindow();
     	  scene = new Scene(root);
     	  stage.setScene(scene);
     	  stage.show();
   }
}
