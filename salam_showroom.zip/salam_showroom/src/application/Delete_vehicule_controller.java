	
	package application;

	import javafx.event.ActionEvent;
	import javafx.fxml.FXML;
	import javafx.fxml.FXMLLoader;
	import javafx.scene.Node;
	import javafx.scene.Parent;
	import javafx.scene.Scene;
	import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TextField;
	import javafx.stage.Stage;
	import model.liste_vehicule;

	import java.io.IOException;
	import java.sql.Connection;
	import java.sql.PreparedStatement;
	import java.sql.SQLException;

	public class Delete_vehicule_controller {
	    
	    @FXML
	    private Button enregistrer;

	    @FXML
	    private TextField nom;

	    @FXML
	    private TextField ID;

	    @FXML
	    private TextField prenom;

	    @FXML
	    private TextField addresse;

	    @FXML
	    private TextField cin;

	    @FXML
	    private TextField telephone;

	    @FXML
	    private TextField salaire;

	    @FXML
	    private ChoiceBox<String> departement;

 private liste_vehicule data;
 
 private liste_vehicule originalData;
 
 private Stage stage;
 private Scene scene;
 private Parent root;


	    @FXML
	    private Button delete;

	    public void setData(liste_vehicule data) {
	        this.data = data;
	        // Set the values to your UI elements if needed
	    }

	    @FXML
	    void DeleteVehicule(ActionEvent event) {
	        // Check if data is not null before proceeding
	        if (this.data == null) {
	            System.out.println("Data is null. Cannot delete.");
	            return;
	        }

	        int id = this.data.getId();

	        try (Connection connection = MysqlConnection.getDBConnection();
	             PreparedStatement preparedStatement = connection.prepareStatement("DELETE FROM stocks WHERE Id = ?")) {

	            preparedStatement.setInt(1, id);
	            int rowsDeleted = preparedStatement.executeUpdate();

	            if (rowsDeleted > 0) {
	                System.out.println("Record deleted successfully!");
	            } else {
	                System.out.println("Record not found or unable to delete.");
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }

	        // Close the stage
	        Stage stage = (Stage) delete.getScene().getWindow();
	        stage.close();
	    }

	    
	    @FXML
	    private Button annuler;
	
	 
   @FXML
   void SwitchToliste(ActionEvent event) throws IOException {
	   // Get the current stage
	   Stage stage = (Stage) annuler.getScene().getWindow();
       stage.close();
   }
	   

	}

	

