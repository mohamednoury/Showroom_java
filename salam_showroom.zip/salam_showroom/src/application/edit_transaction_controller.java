package application;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import model.liste;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class edit_transaction_controller {

    @FXML
    private Label id;

    @FXML
    private Button enregistrer;

    @FXML
    private TextField id_vehicule;

    @FXML
    private TextField id_client;

    @FXML
    private TextField montant;

    @FXML
    private TextField date;

    private liste data;
    
    private liste originalData;
    
    private Connection connection;  // Declare connection at class level

    public void initializeData(liste list) {
        this.originalData = list;
        this.data = new liste(list); // Create a copy of the original data
        id.setText(String.valueOf(list.getId_transaction()));
        id_vehicule.setText(String.valueOf(list.getId_vehicule()));
        id_client.setText(String.valueOf(list.getId_client()));
        date.setText(list.getDate().toString());
        montant.setText(String.valueOf(list.getMantant()));
    }

    @FXML
    void UpdateStock() {
        try {
            // Update data object with new values
            data.setId_vehicule(Integer.parseInt(id_vehicule.getText()));
            data.setId_client(Integer.parseInt(id_client.getText()));
            data.setMantant(Double.parseDouble(montant.getText()));

            // Assuming date is a TextField
            String dateString = date.getText();
            // You may want to add additional validation for the date string before setting it in your data object
            data.setDate(dateString);
        } catch (NumberFormatException e) {
            // Handle parsing errors (e.g., invalid double format)
            // You might want to show an error message to the user
        }

        // Perform the database update
        updateDatabase(data);

        // Close the edit view
        Stage stage = (Stage) enregistrer.getScene().getWindow();
        stage.close();
    }

    private void updateDatabase(liste updatedData) {
        try {
            connection = MysqlConnection.getDBConnection(); // Initialize the connection
            connection.setAutoCommit(false);  // Set auto-commit to false

            String sql = "UPDATE transactions SET id_vehicule=?, id_client=?, date=?, montant=? WHERE Id=?";
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setInt(1, updatedData.getId_vehicule());
                statement.setInt(2, updatedData.getId_client());
                statement.setString(3, updatedData.getDate());
                statement.setDouble(4, updatedData.getMantant());       
                statement.setInt(5, updatedData.getId_transaction());

                statement.executeUpdate();
            }

            // Commit the transaction
            connection.commit();
        } catch (SQLException e) {
            e.printStackTrace(); // Handle the exception according to your application's requirements

            // Rollback the transaction if needed
            try {
                if (connection != null) {
                    connection.rollback();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        } finally {
            // Close the connection in the finally block to ensure it's closed even if an exception occurs
            try {
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }
    
    private Stage stage;
	 private Scene scene;
	 private Parent root;
   
	 
	@FXML
	    private Button annuler;
	
	 
   @FXML
   void SwitchToliste(ActionEvent event) throws IOException {
	   Stage stage = (Stage) annuler.getScene().getWindow();
       stage.close();
   }
}
