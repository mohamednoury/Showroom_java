package application;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;


public class addNewTransactionController {

    @FXML
    private Button ajouterInformation;

    @FXML
    private Button cancel_information;

    @FXML
    private TextField idClient_vehicule;

    @FXML
    private TextField idVehicule;

    @FXML
    private TextField montantVehicule;

    @FXML
    private TextField vehiculeDate;

    @FXML
    void ajouter(ActionEvent event) throws ParseException {
    	int id_vehicule = Integer.parseInt(idVehicule.getText());
    	int id_client = Integer.parseInt(idClient_vehicule.getText());
        String dateString = vehiculeDate.getText();
    	float montant = Float.parseFloat(montantVehicule.getText());

        Date date = parseDate(dateString);

        transaction transac = new transaction(id_vehicule, id_client, date, montant);
        insertTransaction(transac);	

        // Clear input fields
        idVehicule.clear();
        idClient_vehicule.clear();
        vehiculeDate.clear();
        montantVehicule.clear();

    }

    private void insertTransaction(transaction transac) {
        try {
            // Assuming you have a method to get the database connection
            Connection connection = MysqlConnection.getDBConnection();

            // SQL query to insert a new client into the database
            String sql = "INSERT INTO `transactions` (`id_vehicule`, `id_client`, `date`, `montant`) VALUES (?, ?, ?, ?);";

            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setInt(1, transac.getIdVehicule());
            statement.setInt(2, transac.getIdClient());
            statement.setDate(3, new java.sql.Date(transac.getDate().getTime())); // Convert Date to java.sql.Date
            statement.setFloat(4, transac.getMontant());

            statement.executeUpdate();
            
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    private Date parseDate(String dateString) throws ParseException {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        return dateFormat.parse(dateString);
    }

    @FXML
    void cancel_information_method(ActionEvent event) {
        // Clear input fields when the cancel button is clicked
    	idVehicule.clear();
        idClient_vehicule.clear();
        vehiculeDate.clear();
        montantVehicule.clear();
    }
	 private Stage stage;
	 private Scene scene;
	 private Parent root;
  
  
  @FXML
  void SwitchToAddProduit(ActionEvent event) throws IOException {
	  root = FXMLLoader.load(getClass().getResource("nouv_vehicule.fxml"));
	  stage = (Stage)((Node)event.getSource()).getScene().getWindow();
	  scene = new Scene(root);
	  stage.setScene(scene);
	  stage.show();
  }

  @FXML
  void SwitchToAddVehicule(ActionEvent event) throws IOException {
  	  root = FXMLLoader.load(getClass().getResource("nouv_vehicule.fxml"));
    	  stage = (Stage)((Node)event.getSource()).getScene().getWindow();
    	  scene = new Scene(root);
    	  stage.setScene(scene);
    	  stage.show();
  }

  @FXML
  void SwitchToClients(ActionEvent event) throws IOException {
  	  root = FXMLLoader.load(getClass().getResource("liste_des_clients.fxml"));
    	  stage = (Stage)((Node)event.getSource()).getScene().getWindow();
    	  scene = new Scene(root);
    	  stage.setScene(scene);
    	  stage.show();
  }

  @FXML
  void SwitchToDashboard(ActionEvent event) throws IOException {
  	  root = FXMLLoader.load(getClass().getResource("dashboardVoiture.fxml"));
    	  stage = (Stage)((Node)event.getSource()).getScene().getWindow();
    	  scene = new Scene(root);
    	  stage.setScene(scene);
    	  stage.show();
  }

  @FXML
  void SwitchToEmploye(ActionEvent event) throws IOException {
  	  root = FXMLLoader.load(getClass().getResource("liste_des_employes.fxml"));
    	  stage = (Stage)((Node)event.getSource()).getScene().getWindow();
    	  scene = new Scene(root);
    	  stage.setScene(scene);
    	  stage.show();
  }
  @FXML
  void SwitchToStocks(ActionEvent event) throws IOException {
  	  root = FXMLLoader.load(getClass().getResource("liste_de_stock.fxml"));
    	  stage = (Stage)((Node)event.getSource()).getScene().getWindow();
    	  scene = new Scene(root);
    	  stage.setScene(scene);
    	  stage.show();
  }

  @FXML
  void SwitchToTransactions(ActionEvent event) throws IOException {
  	  root = FXMLLoader.load(getClass().getResource("liste_des_transactions.fxml"));
    	  stage = (Stage)((Node)event.getSource()).getScene().getWindow();
    	  scene = new Scene(root);
    	  stage.setScene(scene);
    	  stage.show();
  }
}
