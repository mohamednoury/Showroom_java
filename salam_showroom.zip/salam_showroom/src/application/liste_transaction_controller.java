package application;


import java.io.FileWriter;
import java.io.IOException;
import java.io.Serializable;
import java.net.URL;
import java.rmi.AccessException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.ResourceBundle;
import java.util.stream.Collectors;

import javax.swing.text.html.ImageView;
import javax.swing.tree.DefaultTreeCellEditor.DefaultTextField;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import model.liste;

public class liste_transaction_controller implements Initializable {

	@FXML
    private Button view;
	
	private Stage stage;
	 private Scene scene;
	 private Parent root;
	    @FXML
	    private TextField rechercheTransactionsById;
	    @FXML
	    private TextField rechercheTransactionsByIdVehicule;

	    @FXML
	    private TextField rechercheTransactionsByIdClient;

	    @FXML
	    private TextField rechercheTransactionsByDate;

	    @FXML
	    private TextField rechercheTransactionsByMontant;
	    @FXML
	    private Button exportButton;
	
    @FXML
    private VBox liste_transaction_layout;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
    	loadTransactions();
    	
    	exportButton.setOnAction(event -> exportToCSV());
        List<liste> listesFromDatabase = new ArrayList<>(listesFromDatabase());
        for (int i = 0; i < listesFromDatabase.size(); i++) {
            FXMLLoader fxmlloader = new FXMLLoader();
            fxmlloader.setLocation(getClass().getResource("ithem_transaction.fxml"));

            try {            	
      			HBox hBox = fxmlloader.load();
                ithem_transaction_controller cic = fxmlloader.getController();
                cic.setData(listesFromDatabase.get(i));
                liste_transaction_layout.getChildren().add(hBox);

            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        rechercheTransactionsById.textProperty().addListener((observable, oldValue, newValue) -> {
            searchTransactionById(newValue);
            }
        );
        rechercheTransactionsByIdVehicule.textProperty().addListener((observable, oldValue, newValue) -> {
            searchTransactionByVehiculeId(newValue);
        });

        rechercheTransactionsByIdClient.textProperty().addListener((observable, oldValue, newValue) -> {
            searchTransactionByClientId(newValue);
        });

        rechercheTransactionsByDate.textProperty().addListener((observable, oldValue, newValue) -> {
            searchTransactionByDate(newValue);
        });

        rechercheTransactionsByMontant.textProperty().addListener((observable, oldValue, newValue) -> {
            searchTransactionByMontant(newValue);
        });
    }
    
	  private List<liste> listesFromDatabase() {
		    List<liste> ls = new ArrayList<>();

		    try {
		        Connection connection = MysqlConnection.getDBConnection();

		        String sql = "SELECT * FROM `transactions`";
		        try (PreparedStatement ps = connection.prepareStatement(sql);
		             ResultSet results = ps.executeQuery()) {

		            while (results.next()) {
		                int id = results.getInt("Id");
		                int id_vehicule = results.getInt("id_vehicule");
		                int id_client = results.getInt("id_client");
		                String date = results.getString("date");
		                double mantant = results.getDouble("montant");

		                liste list = new liste();
		                list.setId_transaction(id);
		                list.setId_vehicule(id_vehicule);
		                list.setId_client(id_client);
		                list.setDate(date);
		                list.setMantant(mantant);
		    

		                ls.add(list);
		            }
		        }
		    } catch (SQLException e) {
		        e.printStackTrace(); // Handle exceptions appropriately, you may log or throw a custom exception
		    }

		    return ls;
		   
	}
	  
	  
	  @FXML
	  private void refreshData(ActionEvent event) {
		  loadTransactions(); // Assurez-vous que cette m�thode existe dans votre contr�leur
	  }
	  
	  //button
	  public void SwitchTo(ActionEvent event) throws IOException {
		    Node source = (Node) event.getSource();

		    // Get the scene from the source node
		    Scene scene = source.getScene();

		    if (scene != null) {
		        // Get the stage from the scene
		        Stage currentStage = (Stage) scene.getWindow();

		        if (currentStage != null) {
		            // Load the new scene
		            root = FXMLLoader.load(getClass().getResource("view_client.fxml"));

		            // Create a new scene
		            scene = new Scene(root);

		            // Set the new scene on the current stage
		            currentStage.setScene(scene);

		            // Show the stage
		            currentStage.show();
		        } else {
		            System.out.println("Current stage is null");
		        }
		    } else {
		        System.out.println("Scene is null");
		    }
		}
	  
	   
	   
	   @FXML
	   void SwitchToAddProduit(ActionEvent event) throws IOException {
	 	  root = FXMLLoader.load(getClass().getResource("nouv_vehicule.fxml"));
	 	  stage = (Stage)((Node)event.getSource()).getScene().getWindow();
	 	  scene = new Scene(root);
	 	  stage.setScene(scene);
	 	  stage.show();
	   }
	   @FXML
	   void SwitchToAddTransaction(ActionEvent event) throws IOException {
	 	  root = FXMLLoader.load(getClass().getResource("nouv_trans.fxml"));
	 	  stage = (Stage)((Node)event.getSource()).getScene().getWindow();
	 	  scene = new Scene(root);
	 	  stage.setScene(scene);
	 	  stage.show();
	   }

	   @FXML
	   void SwitchToAddVehicule(ActionEvent event) throws IOException {
	   	  root = FXMLLoader.load(getClass().getResource("nouv_vehicule.fxml"));
	     	  stage = (Stage)((Node)event.getSource()).getScene().getWindow();
	     	  scene = new Scene(root);
	     	  stage.setScene(scene);
	     	  stage.show();
	   }

	   @FXML
	   void SwitchToClients(ActionEvent event) throws IOException {
	   	  root = FXMLLoader.load(getClass().getResource("liste_des_clients.fxml"));
	     	  stage = (Stage)((Node)event.getSource()).getScene().getWindow();
	     	  scene = new Scene(root);
	     	  stage.setScene(scene);
	     	  stage.show();
	   }

	   @FXML
	   void SwitchToDashboard(ActionEvent event) throws IOException {
	   	  root = FXMLLoader.load(getClass().getResource("dashboardVoiture.fxml"));
	     	  stage = (Stage)((Node)event.getSource()).getScene().getWindow();
	     	  scene = new Scene(root);
	     	  stage.setScene(scene);
	     	  stage.show();
	   }

	   @FXML
	   void SwitchToEmploye(ActionEvent event) throws IOException {
	   	  root = FXMLLoader.load(getClass().getResource("liste_des_employes.fxml"));
	     	  stage = (Stage)((Node)event.getSource()).getScene().getWindow();
	     	  scene = new Scene(root);
	     	  stage.setScene(scene);
	     	  stage.show();
	   }
	   @FXML
	   void SwitchToStocks(ActionEvent event) throws IOException {
	   	  root = FXMLLoader.load(getClass().getResource("liste_de_stock.fxml"));
	     	  stage = (Stage)((Node)event.getSource()).getScene().getWindow();
	     	  scene = new Scene(root);
	     	  stage.setScene(scene);
	     	  stage.show();
	   }

	   @FXML
	   void SwitchToTransactions(ActionEvent event) throws IOException {
	   	  root = FXMLLoader.load(getClass().getResource("liste_des_transactions.fxml"));
	     	  stage = (Stage)((Node)event.getSource()).getScene().getWindow();
	     	  scene = new Scene(root);
	     	  stage.setScene(scene);
	     	  stage.show();
	   }

	   @FXML
	   private void exportToCSV() {
	       String csvFilePath = "transactions.csv";

	       try (FileWriter fileWriter = new FileWriter(csvFilePath)) {
	           Connection connection = MysqlConnection.getDBConnection();
	           String sql = "SELECT * FROM transactions";
	           Statement statement = connection.createStatement();
	           ResultSet resultSet = statement.executeQuery(sql);

	           // Write Column Headers
	           fileWriter.append("Id,id_vehicule,id_client,date,montant\n");

	           // Write Data
	           while (resultSet.next()) {
	               fileWriter.append(String.valueOf(resultSet.getInt("Id"))).append(",");
	               fileWriter.append(String.valueOf(resultSet.getInt("id_vehicule"))).append(",");
	               fileWriter.append(String.valueOf(resultSet.getInt("id_client"))).append(",");
	               fileWriter.append(resultSet.getString("date")).append(",");
	               fileWriter.append(String.valueOf(resultSet.getDouble("montant"))).append("\n");
	           }
	       } catch (IOException | SQLException e) {
	           e.printStackTrace(); // Handle exceptions appropriately
	       }
	   }
	  
	   private void searchTransactionById(String searchText) {
		    liste_transaction_layout.getChildren().clear(); // Clear the list first

		    if (searchText.isEmpty()) {
		        // Load all transactions if search text is empty
		        loadTransactions();
		        return;
		    }

		    int searchId;
		    try {
		        searchId = Integer.parseInt(searchText);
		    } catch (NumberFormatException e) {
		        // Handle invalid input (not a number)
		        loadTransactions(); // Load all transactions if input is invalid
		        return;
		    }

		    // Search for the transaction with the given ID
		    liste searchedTransaction = findTransactionById(searchId);
		    if (searchedTransaction != null) {
		        updateTransactionList(Collections.singletonList(searchedTransaction));
		    } else {
		        // Show an alert if no transaction is found
		        Alert alert = new Alert(AlertType.INFORMATION);
		        alert.setTitle("Recherche de Transaction");
		        alert.setHeaderText(null);
		        alert.setContentText("Aucun �l�ment n'est trouv�");
		        alert.showAndWait();
		    }
		}
	   private liste findTransactionById(int id) {
		    liste transaction = null;
		    try {
		        Connection connection = MysqlConnection.getDBConnection();
		        String sql = "SELECT * FROM `transactions` WHERE Id = ?";
		        try (PreparedStatement ps = connection.prepareStatement(sql)) {
		            ps.setInt(1, id);
		            try (ResultSet results = ps.executeQuery()) {
		                if (results.next()) {
		                    int idVehicule = results.getInt("id_vehicule");
		                    int idClient = results.getInt("id_client");
		                    String date = results.getString("date");
		                    double montant = results.getDouble("montant");

		                    transaction = new liste();
		                    transaction.setId_transaction(id);
		                    transaction.setId_vehicule(idVehicule);
		                    transaction.setId_client(idClient);
		                    transaction.setDate(date);
		                    transaction.setMantant(montant);
		                }
		            }
		        }
		    } catch (SQLException e) {
		        e.printStackTrace(); // Proper exception handling should be implemented
		    }
		    return transaction;
		}
	   private void updateTransactionList(List<liste> transactions) {
		    liste_transaction_layout.getChildren().clear(); // Clear current contents
		    for (liste tr : transactions) {
		        FXMLLoader fxmlLoader = new FXMLLoader();
		        fxmlLoader.setLocation(getClass().getResource("ithem_transaction.fxml"));
		        try {
		            HBox hBox = fxmlLoader.load();
		            ithem_transaction_controller controller = fxmlLoader.getController();
		            controller.setData(tr);
		            liste_transaction_layout.getChildren().add(hBox);
		        } catch (IOException e) {
		            e.printStackTrace(); // Proper exception handling should be implemented
		        }
		    }
		}
	   private void loadTransactions() {
		    List<liste> allTransactions = listesFromDatabase();
		    updateTransactionList(allTransactions);
		}

	   private void searchTransactionByVehiculeId(String searchText) {
		    if (searchText.isEmpty()) {
		        loadTransactions(); // Reload all transactions if search text is empty
		        return;
		    }

		    int searchVehiculeId;
		    try {
		        searchVehiculeId = Integer.parseInt(searchText);
		    } catch (NumberFormatException e) {
		        // Handle invalid input (not a number)
		        // Optionally, you could display an error message or clear the list
		        loadTransactions(); // Load all transactions if input is invalid
		        return;
		       
		    }

		    List<liste> filteredTransactions = listesFromDatabase().stream()
		        .filter(tr -> tr.getId_vehicule() == searchVehiculeId)
		        .collect(Collectors.toList());

		    if (filteredTransactions.isEmpty()) {
		        // Show alert if no transaction is found
		        showAlert("Aucun �l�ment n'est trouv�");
		    } else {
		        updateTransactionList(filteredTransactions);
		    }
		}

	   private void showAlert(String message) {
		    Alert alert = new Alert(Alert.AlertType.INFORMATION);
		    alert.setTitle("Information");
		    alert.setHeaderText(null); // No header text
		    alert.setContentText(message);
		    alert.showAndWait();
		}

	   private void searchTransactionByClientId(String searchText) {
		    if (searchText.isEmpty()) {
		        // Load all transactions if search text is empty
		        loadTransactions();
		        return;
		    }

		    int searchClientId;
		    try {
		        searchClientId = Integer.parseInt(searchText);
		    } catch (NumberFormatException e) {
		        // Handle invalid input (not a number)
		        showAlert("Invalid Client ID format.");
		        return;
		    }

		    List<liste> transactions = new ArrayList<>();

		    // Search for the transaction with the given client ID
		    transactions.addAll(listesFromDatabase().stream()
		                        .filter(tr -> tr.getId_client() == searchClientId)
		                        .collect(Collectors.toList()));

		    if (transactions.isEmpty()) {
		        showAlert("Aucun �l�ment n'est trouv� pour l'ID client sp�cifi�.");
		    } else {
		        updateTransactionList(transactions);
		    }
		}
	   private void searchTransactionByDate(String searchText) {
		    if (searchText.isEmpty()) {
		        // Load all transactions if search text is empty
		        loadTransactions();
		        return;
		    }

		    // Assuming the date format in the database is "yyyy-MM-dd"
		    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		    dateFormat.setLenient(false);

		    try {
		        Date searchDate = dateFormat.parse(searchText);

		        List<liste> transactions = listesFromDatabase().stream()
		            .filter(tr -> {
		                try {
		                    return dateFormat.parse(tr.getDate()).equals(searchDate);
		                } catch (ParseException e) {
		                    return false;
		                }
		            })
		            .collect(Collectors.toList());

		        if (transactions.isEmpty()) {
		            showAlert("Aucun �l�ment n'est trouv� pour la date sp�cifi�e.");
		        } else {
		            updateTransactionList(transactions);
		        }

		    } catch (ParseException e) {
		        showAlert("Invalid Date format. Please use yyyy-MM-dd.");
		    }
		}
	   private void searchTransactionByMontant(String searchText) {
		    if (searchText.isEmpty()) {
		        // Load all transactions if search text is empty
		        loadTransactions();
		        return;
		    }

		    double searchMontant;
		    try {
		        searchMontant = Double.parseDouble(searchText);
		    } catch (NumberFormatException e) {
		        showAlert("Invalid montant format. Please enter a valid number.");
		        return;
		    }

		    List<liste> transactions = listesFromDatabase().stream()
		        .filter(tr -> tr.getMantant() == searchMontant)
		        .collect(Collectors.toList());

		    if (transactions.isEmpty()) {
		        showAlert("Aucun �l�ment n'est trouv� pour le montant sp�cifi�.");
		    } else {
		        updateTransactionList(transactions);
		    }
		}


}






