package application;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.time.LocalDate;
import java.util.ResourceBundle;
import javafx.scene.Node;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.stage.Stage;

public class controller {

    @FXML
    private BarChart<String, Integer> barChart;

    @FXML
    private CategoryAxis x;

    @FXML
    private NumberAxis y;

    @FXML
    private Label nbr_client;

    @FXML
    private Label nbr_employee;

    @FXML
    private Label revenue_total;

    @FXML
    private ListView<String> historicListView;
    
    @FXML
    private Label nom_complet;
    
    private String userEmail;
    private String userNomComplet;

    // M�thode pour d�finir les d�tails de l'utilisateur depuis le LoginController
    public void setUserDetails(String email, String nomComplet) {
        this.userEmail = email;
        this.userNomComplet = nomComplet;
        
        // Mettez � jour l'affichage du nom complet dans votre interface utilisateur (label nom_complet)
        nom_complet.setText(nomComplet);
        
    }

    private void updateChart(LocalDate selectedDate) {
        try {
            Connection connection = MysqlConnection.getDBConnection();

            String stockSql = "SELECT Marque, SUM(quantite) AS total FROM stocks WHERE date_st = ? GROUP BY Marque";
            String transactionSql = "SELECT s.Marque, COUNT(*) AS total FROM transactions t " +
                    "JOIN stocks s ON t.id_vehicule = s.Id " +
                    "WHERE t.date = ? GROUP BY s.Marque";

            XYChart.Series<String, Integer> stockSeries = createSeries(selectedDate, connection, stockSql, "Stock");
            XYChart.Series<String, Integer> transactionSeries = createSeries(selectedDate, connection, transactionSql, "Transaction");

            // Set the series data in the BarChart
            barChart.getData().clear();
            barChart.getData().addAll(stockSeries, transactionSeries);

        } catch (Exception e) {
            e.printStackTrace(); // Print the exception details for debugging
        }
    }

    private XYChart.Series<String, Integer> createSeries(LocalDate selectedDate, Connection connection, String sql, String seriesName) throws Exception {
        PreparedStatement ps = connection.prepareStatement(sql);
        ps.setDate(1, java.sql.Date.valueOf(selectedDate));
        ResultSet rs = ps.executeQuery();

        XYChart.Series<String, Integer> series = new XYChart.Series<>();
        series.setName(seriesName);

        while (rs.next()) {
            String marque = rs.getString("Marque");
            int quantite = rs.getInt("total");
            series.getData().add(new XYChart.Data<>(marque, quantite));
        }

        return series;
    }
	 private Stage stage;
	 private Scene scene;
	 private Parent root;

    @FXML
    private DatePicker myDatePicker;

    @FXML
    private Label myLabel;

    public void getDate(ActionEvent event) {
        LocalDate selectedDate = myDatePicker.getValue();
        updateChart(selectedDate);
        System.out.println(selectedDate.toString());

        // You can now use the selectedDate in your SQL queries.
        try {
            Connection connection = MysqlConnection.getDBConnection();

            String sql;
            PreparedStatement ps;
            ResultSet rs;

            // Query 1 with date condition
            sql = "SELECT COUNT(*) count FROM clients WHERE date_Cl = ?;";
            ps = connection.prepareStatement(sql);
            ps.setDate(1, java.sql.Date.valueOf(selectedDate));
            rs = ps.executeQuery();
            while (rs.next()) {
                int count = rs.getInt("count");
                nbr_client.setText(String.valueOf(count));
            }

            // Query 2 with date condition
            sql = "SELECT COUNT(*) count FROM employes WHERE date_Em = ?;";
            ps = connection.prepareStatement(sql);
            ps.setDate(1, java.sql.Date.valueOf(selectedDate));
            rs = ps.executeQuery();
            if (rs.next()) {
                int count = rs.getInt("count");
                nbr_employee.setText(String.valueOf(count));
            }

            // Query 3 with date condition
            sql = "SELECT SUM(montant) count FROM transactions WHERE date = ?;";
            ps = connection.prepareStatement(sql);
            ps.setDate(1, java.sql.Date.valueOf(selectedDate));
            rs = ps.executeQuery();
            if (rs.next()) {
                float count = rs.getFloat("count");
                revenue_total.setText(String.valueOf(count));
            }
            
            // Query to fetch transaction data
            sql = "SELECT id, montant FROM transactions WHERE date = ?;";
            ps = connection.prepareStatement(sql);
            ps.setDate(1, java.sql.Date.valueOf(selectedDate));
            rs = ps.executeQuery();

            ObservableList<String> transactions = FXCollections.observableArrayList();
            while (rs.next()) {
                int id = rs.getInt("id");
                float montant = rs.getFloat("montant");
                transactions.add("id: " + id + ", montant: " + montant + " DHs");
            }

            // Set the transactions in the ListView
            historicListView.setItems(transactions);

        } catch (Exception e) {
            e.printStackTrace(); // Print the exception details for debugging
        }
    }
	   @FXML
	   void SwitchToClients(ActionEvent event) throws IOException {
	   	  root = FXMLLoader.load(getClass().getResource("liste_des_clients.fxml"));
	     	  stage = (Stage)((Node)event.getSource()).getScene().getWindow();
	     	  scene = new Scene(root);
	     	  stage.setScene(scene);
	     	  stage.show();
	   }

	   @FXML
	   void SwitchToEmployes(ActionEvent event) throws IOException {
	   	  root = FXMLLoader.load(getClass().getResource("liste_des_employes.fxml"));
	     	  stage = (Stage)((Node)event.getSource()).getScene().getWindow();
	     	  scene = new Scene(root);
	     	  stage.setScene(scene);
	     	  stage.show();
	   }
	   @FXML
	   void SwitchToProduit(ActionEvent event) throws IOException {
	 	  root = FXMLLoader.load(getClass().getResource("nouv_vehicule.fxml"));
	 	  stage = (Stage)((Node)event.getSource()).getScene().getWindow();
	 	  scene = new Scene(root);
	 	  stage.setScene(scene);
	 	  stage.show();
	   }

	   @FXML
	   void SwitchToStock(ActionEvent event) throws IOException {
	   	  root = FXMLLoader.load(getClass().getResource("liste_de_stock.fxml"));
	     	  stage = (Stage)((Node)event.getSource()).getScene().getWindow();
	     	  scene = new Scene(root);
	     	  stage.setScene(scene);
	     	  stage.show();
	   }

	   @FXML
	   void SwitchToTransactions(ActionEvent event) throws IOException {
	 	  root = FXMLLoader.load(getClass().getResource("liste_des_transactions.fxml"));
	 	  stage = (Stage)((Node)event.getSource()).getScene().getWindow();
	 	  scene = new Scene(root);
	 	  stage.setScene(scene);
	 	  stage.show();
	   }
    
}