package application;

public class employee {
    private String lastName;
    private String firstName;
    private String CIN;
    private String address;
    private String phone;
    private String department;
    private float salary;

    public employee(String lastName, String firstName, String CIN, String address, String phone, String department, float salary) {
        this.lastName = lastName;
        this.firstName = firstName;
        this.CIN = CIN;
        this.address = address;
        this.phone = phone;
        this.department = department;
        this.salary = salary;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getCIN() {
        return CIN;
    }

    public void setCIN(String CIN) {
        this.CIN = CIN;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getDepartment() {
        return department;
    }

    public void department(String department) {
        this.department = department;
    }

    public float getSalary() {
        return salary;
    }

    public void setPhone(float salary) {
        this.salary = salary;
    }
}
