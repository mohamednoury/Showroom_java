package model;

public class liste_clients {
	
    private int Id; 
    private String Nom;
    private String Prenom; 
    private String Cin; 
    private String Adresse;
    private String Telephone;
    
	public liste_clients() {
		super();
	}

	public liste_clients(int id, String nom, String prenom, String cin, String adresse, String telephone) {
		super();
		Id = id;
		Nom = nom;
		Prenom = prenom;
		Cin = cin;
		Adresse = adresse;
		Telephone = telephone;
	}

	public int getId() {
		return Id;
	}

	public void setId(int id) {
		Id = id;
	}

	public String getNom() {
		return Nom;
	}

	public void setNom(String nom) {
		Nom = nom;
	}

	public String getPrenom() {
		return Prenom;
	}

	public void setPrenom(String prenom) {
		Prenom = prenom;
	}

	public String getCin() {
		return Cin;
	}

	public void setCin(String cin) {
		Cin = cin;
	}

	public String getAdresse() {
		return Adresse;
	}

	public void setAdresse(String adresse) {
		Adresse = adresse;
	}

	public String getTelephone() {
		return Telephone;
	}

	public void setTelephone(String telephone) {
		Telephone = telephone;
	}
	
	
	

    
}
