package model;


public class liste {
	
    private int id_transaction;
    private int id_client; 
    private int id_vehicule;
	private double mantant ;
	private String date;
	
	public int getId_transaction() {
		return id_transaction;
	}
	public void setId_transaction(int id_transaction) {
		this.id_transaction = id_transaction;
	}
	public int getId_client() {
		return id_client;
	}
	public void setId_client(int id_client) {
		this.id_client = id_client;
	}
	public int getId_vehicule() {
		return id_vehicule;
	}
	public void setId_vehicule(int id_vehicule) {
		this.id_vehicule = id_vehicule;
	}
	public double getMantant() {
		return mantant;
	}
	public void setMantant(double mantant) {
		this.mantant = mantant;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public liste() {
		super();
	}
	
	public liste(liste other) {
        this.id_transaction = other.id_transaction;
        this.id_vehicule = other.id_vehicule;
        this.id_client = other.id_client;
        this.date = other.date;
        this.mantant = other.mantant;
    }
		
}
