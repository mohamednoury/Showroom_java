package model;

import javafx.scene.image.Image;

public class liste_vehicule {
	
    private int Id; 
    private String Marque;
    private String modele; 
    private double prix_achat; 
    private double prix_vente;
    private int quantite;
    private String Date_sortie;
    private String status;
    private String imagePath; // Use a String to store the file path or URL of the image
    
    
	public String getImagePath() {
		return imagePath;
	}
	public void setImagePath(String imagePath) {
		this.imagePath = imagePath;
	}
	public int getId() {
		return Id;
	}
	public void setId(int id) {
		Id = id;
	}
	public String getMarque() {
		return Marque;
	}
	public void setMarque(String marque) {
		Marque = marque;
	}
	public String getModele() {
		return modele;
	}
	public void setModele(String modele) {
		this.modele = modele;
	}
	public double getPrix_achat() {
		return prix_achat;
	}
	public void setPrix_achat(double prix_achat) {
		this.prix_achat = prix_achat;
	}
	public double getPrix_vente() {
		return prix_vente;
	}
	public void setPrix_vente(double prix_vente) {
		this.prix_vente = prix_vente;
	}
	public int getQuantite() {
		return quantite;
	}
	public void setQuantite(int quantite) {
		this.quantite = quantite;
	}
	public String getDate_sortie() {
		return Date_sortie;
	}
	public void setDate_sortie(String date_sortie) {
		Date_sortie = date_sortie;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public liste_vehicule() {
		super();
	}
	public void setImagePath(Image image) {
		// TODO Auto-generated method stub
		
	}
    
    
    
		
	 
}
