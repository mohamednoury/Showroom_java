package model;

public class liste_employes {
	
    private int Id; 
    private String Nom;
    private String Prenom; 
    private String Cin; 
    private String Adresse;
    private String Telephone;
    private String departement;
    private double salaire;
    
    
    
    
	public liste_employes(int id, String nom, String prenom, String cin, String adresse, String telephone, String departement,
			double salaire) {
		super();
		Id = id;
		Nom = nom;
		Prenom = prenom;
		Cin = cin;
		Adresse = adresse;
		Telephone = telephone;
		this.departement = departement;
		this.salaire = salaire;
	}

	
	public liste_employes() {
		super();
	}

	public int getId() {
		return Id;
	}

	public void setId(int id) {
		Id = id;
	}

	public String getNom() {
		return Nom;
	}

	public void setNom(String nom) {
		Nom = nom;
	}

	public String getPrenom() {
		return Prenom;
	}

	public void setPrenom(String prenom) {
		Prenom = prenom;
	}

	public String getCin() {
		return Cin;
	}

	public void setCin(String cin) {
		Cin = cin;
	}

	public String getAdresse() {
		return Adresse;
	}

	public void setAdresse(String adresse) {
		Adresse = adresse;
	}

	public String getTelephone() {
		return Telephone;
	}

	public void setTelephone(String telephone) {
		Telephone = telephone;
	}

	public String getDepartement() {
		return departement;
	}

	public void setDepartement(String departement) {
		this.departement = departement;
	}

	public double getSalaire() {
		return salaire;
	}

	public void setSalaire(double salaire) {
		this.salaire = salaire;
	}
	 
}
